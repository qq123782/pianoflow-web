
import React, { useState, useEffect } from 'react';
import { PianoCanvas } from './components/PianoCanvas';
import { UIOverlay } from './components/UIOverlay';
import { AITeacherSidebar } from './components/AITeacherSidebar';
import { SongLibrary } from './components/SongLibrary';
import { SoundSettings } from './components/SoundSettings'; 
import { midiService } from './services/midiService';
import { audioService } from './services/audioService';
import { BUILT_IN_SONGS } from './services/songLoader';
import { GameStats, AiGeneratedExercise, SongNote, NoteState, AnalysisPayload, SongMetadata, ThemeMode } from './types';
import { Loader2 } from 'lucide-react';
import * as Tone from 'tone';

const App: React.FC = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isWaitMode, setIsWaitMode] = useState(false); 
  const [isBackingTrackOn, setIsBackingTrackOn] = useState(true); 
  const [isAutoPlay, setIsAutoPlay] = useState(false); 
  
  // Theme State
  const [theme, setTheme] = useState<ThemeMode>('classic');

  const [isAiOpen, setIsAiOpen] = useState(false);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false); 
  
  const [currentSong, setCurrentSong] = useState<SongMetadata>(BUILT_IN_SONGS[0]);
  const [songData, setSongData] = useState<SongNote[]>(BUILT_IN_SONGS[0].notes || []);
  
  const [savedSongs, setSavedSongs] = useState<SongMetadata[]>(() => {
    try {
      const local = localStorage.getItem('piano_saved_songs');
      return local ? JSON.parse(local) : [];
    } catch (e) {
      console.error("Failed to load saved songs", e);
      return [];
    }
  });

  const [stats, setStats] = useState<GameStats>({
    score: 0, streak: 0, maxStreak: 0, hits: { perfect: 0, good: 0, miss: 0 }
  });
  
  const [analysisData, setAnalysisData] = useState<AnalysisPayload | null>(null);

  useEffect(() => {
    const init = async () => {
      await midiService.init();
      setIsLoaded(true);
    };
    init();

    // Wake Lock Logic
    let wakeLock: any = null;
    const requestWakeLock = async () => {
      if (!('wakeLock' in navigator)) return;
      try {
        wakeLock = await (navigator as any).wakeLock.request('screen');
      } catch (err: any) {
        if (err.name !== 'NotAllowedError') console.warn('Wake Lock error:', err);
      }
    };
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') requestWakeLock();
    };

    requestWakeLock();
    document.addEventListener('visibilitychange', handleVisibilityChange);

    const handleUserGesture = () => {
      audioService.init();
      requestWakeLock();
      window.removeEventListener('click', handleUserGesture);
      window.removeEventListener('keydown', handleUserGesture);
      window.removeEventListener('touchstart', handleUserGesture);
    };

    window.addEventListener('click', handleUserGesture);
    window.addEventListener('keydown', handleUserGesture);
    window.addEventListener('touchstart', handleUserGesture);

    return () => {
      window.removeEventListener('click', handleUserGesture);
      window.removeEventListener('keydown', handleUserGesture);
      window.removeEventListener('touchstart', handleUserGesture);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      if (wakeLock) wakeLock.release().catch(() => {});
    };
  }, []);

  useEffect(() => {
    localStorage.setItem('piano_saved_songs', JSON.stringify(savedSongs));
  }, [savedSongs]);

  useEffect(() => {
    if (currentSong.audioPreset) {
      audioService.applyPreset(currentSong.audioPreset);
    } else {
      audioService.applyPreset('Standard');
    }
  }, [currentSong]);

  useEffect(() => {
      if (isPlaying) {
          audioService.stopAll();
          if (currentSong.backingNotes && currentSong.backingNotes.length > 0) {
              audioService.previewSong([], currentSong.backingNotes);
          }
      } else {
          audioService.stopAll();
      }
  }, [isPlaying, currentSong]);

  const handleTogglePlay = async () => {
    await audioService.init(); 
    setIsPlaying(!isPlaying);
  };

  const handleToggleBackingTrack = () => {
      const newState = !isBackingTrackOn;
      setIsBackingTrackOn(newState);
      audioService.setBackingTrackEnabled(newState);
  };

  const handleReset = () => {
    setIsPlaying(false);
    if (currentSong.notes) {
        setSongData(JSON.parse(JSON.stringify(currentSong.notes)));
    }
    setStats({ score: 0, streak: 0, maxStreak: 0, hits: { perfect: 0, good: 0, miss: 0 } });
  };

  const handleAnalyzePerformance = () => {
    setIsPlaying(false);
    setAnalysisData({
      songTitle: currentSong.title,
      stats: stats
    });
    setIsAiOpen(true);
  };

  const handleSongSelect = (song: SongMetadata) => {
    setIsPlaying(false);
    setCurrentSong(song);
    setIsBackingTrackOn(true);
    audioService.setBackingTrackEnabled(true);
    if (song.notes) {
        setSongData(JSON.parse(JSON.stringify(song.notes)));
    }
    setStats({ score: 0, streak: 0, maxStreak: 0, hits: { perfect: 0, good: 0, miss: 0 } });
  };

  const convertAiExerciseToSong = (exercise: AiGeneratedExercise): SongMetadata => {
    const beatDuration = 60 / exercise.bpm;
    let currentStartTime = 2.0; 

    const newNotes: SongNote[] = exercise.notes
      .filter(n => n.note !== 'REST')
      .map((n, idx) => {
        const midi = Tone.Frequency(n.note).toMidi();
        const durationSeconds = n.duration * beatDuration;
        
        const noteObj: SongNote = {
          id: `ai-note-${Date.now()}-${idx}`,
          midi: midi,
          startTime: currentStartTime,
          duration: durationSeconds,
          state: NoteState.Waiting
        };
        currentStartTime += durationSeconds;
        return noteObj;
      });
    
    let backingNotes: SongNote[] = [];
    if (exercise.backingNotes && exercise.backingNotes.length > 0) {
        let backingStartTime = 2.0; 
        backingNotes = exercise.backingNotes
            .filter(n => n.note !== 'REST')
            .map((n, idx) => {
                const midi = Tone.Frequency(n.note).toMidi();
                const durationSeconds = n.duration * beatDuration;
                
                const noteObj: SongNote = {
                    id: `ai-backing-${Date.now()}-${idx}`,
                    midi: midi,
                    startTime: backingStartTime,
                    duration: durationSeconds,
                    state: NoteState.Waiting
                };
                backingStartTime += durationSeconds;
                return noteObj;
            });
    }

    return {
        id: `ai-saved-${Date.now()}`,
        title: exercise.title,
        artist: 'AI 生成',
        difficulty: 'Medium',
        bpm: exercise.bpm,
        notes: newNotes,
        backingNotes: backingNotes, 
        audioPreset: exercise.audioPreset 
    };
  };

  const handleLoadAiExercise = (exercise: AiGeneratedExercise, mode: 'full' | 'piano' = 'full') => {
    setIsPlaying(false);
    const newSong = convertAiExerciseToSong(exercise);
    setCurrentSong(newSong);
    setSongData(newSong.notes || []);
    setStats({ score: 0, streak: 0, maxStreak: 0, hits: { perfect: 0, good: 0, miss: 0 } });
    
    if (mode === 'piano') {
        setIsBackingTrackOn(false);
        audioService.setBackingTrackEnabled(false);
    } else {
        setIsBackingTrackOn(true);
        audioService.setBackingTrackEnabled(true);
    }
    
    setTimeout(() => {
      handleTogglePlay();
    }, 500);
  };

  const handleSaveAiSong = (exercise: AiGeneratedExercise) => {
    const newSong = convertAiExerciseToSong(exercise);
    if (savedSongs.some(s => s.title === newSong.title)) {
      return;
    }
    setSavedSongs(prev => [newSong, ...prev]);
  };

  const handleToggleTheme = () => {
     setTheme(prev => {
         if (prev === 'classic') return 'neon';
         if (prev === 'neon') return 'fruit';
         if (prev === 'fruit') return 'starry';
         if (prev === 'starry') return 'dream';
         return 'classic';
     });
  };

  if (!isLoaded) {
    return (
      <div className="h-screen w-screen bg-slate-900 flex items-center justify-center text-white">
        <Loader2 className="animate-spin mr-2" /> Initializing App...
      </div>
    );
  }

  return (
    <div className="relative w-screen h-screen bg-slate-900 overflow-hidden select-none">
      
      <PianoCanvas 
        isPlaying={isPlaying}
        isWaitMode={isWaitMode} 
        isAutoPlay={isAutoPlay} 
        songData={songData}
        onStatsUpdate={setStats}
        playbackSpeed={1}
        theme={theme}
      />

      <UIOverlay 
        isPlaying={isPlaying}
        isWaitMode={isWaitMode}
        isBackingTrackOn={isBackingTrackOn} 
        isAutoPlay={isAutoPlay}
        stats={stats}
        theme={theme}
        onTogglePlay={handleTogglePlay}
        onToggleWaitMode={() => setIsWaitMode(!isWaitMode)}
        onToggleBackingTrack={handleToggleBackingTrack} 
        onToggleAutoPlay={() => setIsAutoPlay(!isAutoPlay)} 
        onReset={handleReset}
        onToggleAI={() => { setIsAiOpen(!isAiOpen); setIsLibraryOpen(false); setIsSettingsOpen(false); }}
        onToggleLibrary={() => { setIsLibraryOpen(!isLibraryOpen); setIsAiOpen(false); setIsSettingsOpen(false); }}
        onToggleSettings={() => { setIsSettingsOpen(!isSettingsOpen); setIsLibraryOpen(false); setIsAiOpen(false); }}
        onAnalyze={handleAnalyzePerformance}
        onToggleTheme={handleToggleTheme}
        isAiOpen={isAiOpen}
        isLibraryOpen={isLibraryOpen}
      />
      
      <AITeacherSidebar 
        isOpen={isAiOpen} 
        onClose={() => setIsAiOpen(false)} 
        onLoadExercise={handleLoadAiExercise}
        onSaveExercise={handleSaveAiSong} 
        analysisData={analysisData}
        onAnalysisComplete={() => setAnalysisData(null)}
      />

      <SongLibrary 
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        onSelectSong={handleSongSelect}
        savedSongs={savedSongs}
      />

      <SoundSettings 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

    </div>
  );
};

export default App;
