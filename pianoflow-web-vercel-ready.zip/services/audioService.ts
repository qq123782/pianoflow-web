
import * as Tone from 'tone';
import { SongNote } from '../types';

export type AudioPresetName = 'Standard' | 'Concert' | 'Warm' | 'Bright' | 'Cosmic';

interface AudioPreset {
  eq: { low: number; mid: number; high: number };
  reverb: { decay: number; wet: number };
  delay?: { delayTime: string | number; feedback: number; wet: number }; // New Delay Effect
}

const PRESETS: Record<AudioPresetName, AudioPreset> = {
  'Standard': {
    eq: { low: 0, mid: 0, high: 0 },
    reverb: { decay: 1.5, wet: 0.2 }
  },
  'Concert': {
    eq: { low: 5, mid: -2, high: 3 },
    reverb: { decay: 5.0, wet: 0.5 }, // Increased decay for Grand Hall
    delay: { delayTime: "8n", feedback: 0.2, wet: 0.1 } // Subtle echo
  },
  'Warm': {
    eq: { low: 8, mid: 2, high: -10 }, // Heavy high cut for "Felt Piano"
    reverb: { decay: 3.0, wet: 0.35 }
  },
  'Bright': {
    eq: { low: -2, mid: 5, high: 10 }, 
    reverb: { decay: 1.2, wet: 0.1 }
  },
  'Cosmic': {
    // INTERSTELLAR SPECIAL SETTINGS: Organ/Pad Texture
    eq: { low: 8, mid: -5, high: 2 }, // Boost bass for the organ drone
    reverb: { decay: 10.0, wet: 0.7 }, // Massive reverb
    delay: { delayTime: "4n.", feedback: 0.6, wet: 0.4 } 
  }
};

class AudioService {
  private sampler: Tone.Sampler | null = null;
  private backingSynth: Tone.PolySynth | null = null; 
  private backingGain: Tone.Gain | null = null; // NEW: Dedicated volume control for backing
  
  private reverb: Tone.Reverb | null = null;
  private delay: Tone.PingPongDelay | null = null; 
  private eq: Tone.EQ3 | null = null;
  private compressor: Tone.Compressor | null = null;
  private limiter: Tone.Limiter | null = null;
  
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;
  
  // Mute State for Backing Track
  private isBackingEnabled = true; 
  private currentBackingVolumeLevel = -4; 

  // Current settings state
  public currentSettings = {
    eqLow: 0,
    eqMid: 0,
    eqHigh: 0,
    reverbWet: 0.2
  };

  public async init() {
    if (this.isInitialized) return;
    if (this.initPromise) return this.initPromise;

    this.initPromise = new Promise(async (resolve) => {
      try {
        // 1. LATENCY SETUP
        Tone.context.lookAhead = 0.05; 
        await Tone.start();
        if (Tone.context.state !== 'running') {
          await Tone.context.resume();
        }
        console.log("Audio Context Started (Dual-Engine Mode)");

        // 2. AUDIO CHAIN SETUP
        this.limiter = new Tone.Limiter(-1).toDestination();
        
        this.reverb = new Tone.Reverb({
          decay: 2.5,
          preDelay: 0.01,
          wet: 0.25
        });
        await this.reverb.generate();

        this.delay = new Tone.PingPongDelay({
            delayTime: "8n",
            feedback: 0.2,
            wet: 0
        });

        this.compressor = new Tone.Compressor({
          threshold: -20,
          ratio: 3,
          attack: 0.05,
          release: 0.2
        });

        this.eq = new Tone.EQ3(0, 0, 0);

        // 3. PIANO SAMPLER (User Instrument)
        this.sampler = new Tone.Sampler({
          urls: {
            A0: "A0.mp3", C1: "C1.mp3", "D#1": "Ds1.mp3", "F#1": "Fs1.mp3",
            A1: "A1.mp3", C2: "C2.mp3", "D#2": "Ds2.mp3", "F#2": "Fs2.mp3",
            A2: "A2.mp3", C3: "C3.mp3", "D#3": "Ds3.mp3", "F#3": "Fs3.mp3",
            A3: "A3.mp3", C4: "C4.mp3", "D#4": "Ds4.mp3", "F#4": "Fs4.mp3",
            A4: "A4.mp3", C5: "C5.mp3", "D#5": "Ds5.mp3", "F#5": "Fs5.mp3",
            A6: "A6.mp3", C7: "C7.mp3", "D#7": "Ds7.mp3", "F#7": "Fs7.mp3",
            A7: "A7.mp3", C8: "C8.mp3"
          },
          release: 1,
          baseUrl: "https://tonejs.github.io/audio/salamander/",
          onload: () => {
            console.log("Piano Samples Loaded!");
            this.isInitialized = true;
            resolve();
          },
          onerror: (err) => {
             console.error("Sample loading error:", err);
             resolve();
          }
        });

        // 4. BACKING SYNTH CHAIN
        // New Architecture: Synth -> GainNode -> Reverb -> Out
        this.backingGain = new Tone.Gain(this.isBackingEnabled ? 1 : 0);
        
        this.backingSynth = new Tone.PolySynth(Tone.Synth, {
          oscillator: {
            type: "fatsawtooth",
            count: 3,
            spread: 30
          },
          envelope: {
            attack: 0.8,  
            decay: 1,
            sustain: 1,   
            release: 3    
          },
          volume: this.currentBackingVolumeLevel
        });

        if (this.sampler && this.backingSynth && this.backingGain && this.eq && this.compressor && this.reverb && this.delay) {
            // Chain: Piano -> EQ -> Compressor -> Delay -> Reverb -> Limiter
            this.sampler.chain(this.eq, this.compressor, this.delay, this.reverb, this.limiter);
            
            // Chain: Backing Synth -> Backing Gain -> Reverb -> Limiter
            // Using a dedicated gain node makes muting INSTANT and reliable.
            this.backingSynth.connect(this.backingGain);
            this.backingGain.connect(this.reverb);
            
            this.sampler.volume.value = 0; 
        }

      } catch (e) {
        console.error("Could not start Audio Context", e);
        resolve();
      }
    });

    return this.initPromise;
  }

  public resumeContext() {
    if (Tone.context.state !== 'running') {
      Tone.context.resume();
    }
  }

  public setBackingTrackEnabled(enabled: boolean) {
      this.isBackingEnabled = enabled;
      if (this.backingGain) {
          // Use rampTo for a tiny fade to prevent clicking, but fast enough to feel instant
          // 0.05s is 50ms, which is immediate to the ear but click-free.
          this.backingGain.gain.rampTo(enabled ? 1 : 0, 0.05);
      }
  }

  // --- TUNING & EFFECTS ---

  public applyPreset(name: AudioPresetName) {
    const p = PRESETS[name];
    if (!p) return;

    const apply = () => {
        this.setEQ(p.eq.low, p.eq.mid, p.eq.high);
        this.setReverb(p.reverb.wet, p.reverb.decay);
        
        if (this.delay) {
            if (p.delay) {
                this.delay.wet.value = p.delay.wet;
                this.delay.feedback.value = p.delay.feedback;
                this.delay.delayTime.value = p.delay.delayTime;
            } else {
                this.delay.wet.value = 0;
            }
        }

        if (this.backingSynth) {
            let targetVolume = -4; 

            if (name === 'Cosmic') {
                // Interstellar Organ Mode
                // Longer release for massive drone feel
                // Faster attack to feel more like an organ than a slow pad
                this.backingSynth.set({ 
                    envelope: { attack: 0.2, release: 5.0, sustain: 1.0, decay: 0.5 },
                    oscillator: { type: "fatsawtooth", count: 3, spread: 40 }
                }); 
                targetVolume = -2; 
            } else if (name === 'Bright') {
                this.backingSynth.set({ envelope: { attack: 0.1, release: 0.5 } }); 
                targetVolume = -8;
            } else {
                this.backingSynth.set({ envelope: { attack: 0.8, release: 2 } }); 
                targetVolume = -4;
            }

            this.currentBackingVolumeLevel = targetVolume;
            this.backingSynth.volume.rampTo(targetVolume, 0.1);
        }
    };

    if (!this.isInitialized && !this.initPromise) {
        this.init().then(apply);
    } else {
        apply();
    }
    console.log(`Audio Preset Applied: ${name}`);
  }

  public setEQ(low: number, mid: number, high: number) {
    if (this.eq) {
        this.eq.low.value = low;
        this.eq.mid.value = mid;
        this.eq.high.value = high;
    }
    
    this.currentSettings.eqLow = low;
    this.currentSettings.eqMid = mid;
    this.currentSettings.eqHigh = high;
  }

  public setReverb(wet: number, decay?: number) {
    if (this.reverb) {
        this.reverb.wet.value = Math.max(0, Math.min(1, wet));
        if (decay && decay !== this.reverb.decay) {
            this.reverb.decay = decay;
            this.reverb.generate();
        }
    }
    this.currentSettings.reverbWet = wet;
  }

  // --- PLAYBACK ---

  public playNote(noteName: string | number, duration: number = 0.5, velocity: number = 0.7) {
    if (!this.sampler || !this.isInitialized || !this.sampler.loaded) return;
    this.resumeContext();
    const freq = typeof noteName === 'number' ? Tone.Frequency(noteName, "midi").toNote() : noteName;
    this.sampler.triggerAttackRelease(freq, duration, Tone.context.currentTime, velocity);
  }

  public startNote(midi: number, velocity: number = 0.7) {
    if (!this.sampler || !this.isInitialized || !this.sampler.loaded) {
        if(!this.initPromise) this.init();
        return;
    }
    this.resumeContext();
    const freq = Tone.Frequency(midi, "midi").toNote();
    this.sampler.triggerAttack(freq, Tone.context.currentTime, velocity);
  }

  public stopNote(midi: number) {
    if (!this.sampler || !this.isInitialized || !this.sampler.loaded) return;
    const freq = Tone.Frequency(midi, "midi").toNote();
    this.sampler.triggerRelease(freq, Tone.context.currentTime);
  }

  public async stopAll() {
    Tone.Transport.stop();
    Tone.Transport.cancel();
    if (this.sampler && this.sampler.loaded) {
        this.sampler.releaseAll();
    }
    if (this.backingSynth) {
        this.backingSynth.releaseAll();
    }
  }

  public getCurrentTime(): number {
      return Tone.Transport.seconds;
  }

  public async previewSong(notes: SongNote[], backingNotes?: SongNote[]) {
    await this.init();
    this.stopAll(); 

    if ((!notes || notes.length === 0) && (!backingNotes || backingNotes.length === 0)) return;
    if (!this.sampler || !this.sampler.loaded) return;

    // 1. Schedule Main Melody (Piano)
    if (notes && notes.length > 0) {
        notes.forEach(note => {
          Tone.Transport.schedule((t) => {
              if (this.sampler && this.sampler.loaded) {
                  this.sampler.triggerAttackRelease(
                  Tone.Frequency(note.midi, "midi").toNote(), 
                  note.duration, 
                  t
                  );
              }
          }, note.startTime);
        });
    }

    // 2. Schedule Backing Track (Synth) - Auto played
    if (backingNotes && backingNotes.length > 0 && this.backingSynth) {
        backingNotes.forEach(note => {
            Tone.Transport.schedule((t) => {
                // We play the note regardless, but the GainNode controls if it's heard.
                // This ensures no logic glitches if we toggle mid-song.
                if (this.backingSynth) {
                      this.backingSynth.triggerAttackRelease(
                          Tone.Frequency(note.midi, "midi").toNote(),
                          note.duration,
                          t,
                          0.5 
                      );
                }
            }, note.startTime);
        });
    }

    Tone.Transport.start();
  }
}

export const audioService = new AudioService();
