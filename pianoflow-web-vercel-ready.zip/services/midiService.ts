export type MidiCallback = (command: number, note: number, velocity: number) => void;

class MidiService {
  private access: any = null;
  private input: any = null;
  private listeners: MidiCallback[] = [];

  public async init(): Promise<boolean> {
    if (!(navigator as any).requestMIDIAccess) {
      console.warn("WebMIDI is not supported in this browser.");
      return false;
    }

    try {
      this.access = await (navigator as any).requestMIDIAccess();
      
      // Auto-select the first input
      if (this.access.inputs.size > 0) {
        const inputs = Array.from(this.access.inputs.values());
        this.setInput(inputs[0]);
      }

      this.access.onstatechange = (e: any) => {
        // Handle device connection/disconnection dynamically
        console.log("MIDI State Change", e);
      };

      return true;
    } catch (err) {
      console.error("MIDI Access Failed", err);
      return false;
    }
  }

  public setInput(input: any) {
    if (this.input) {
      this.input.onmidimessage = null; // Cleanup
    }
    this.input = input;
    this.input.onmidimessage = this.handleMidiMessage.bind(this);
    console.log(`MIDI Input Connected: ${input.name}`);
  }

  private handleMidiMessage(event: any) {
    const [command, note, velocity] = event.data;
    // Notify all listeners
    this.listeners.forEach(fn => fn(command, note, velocity));
  }

  public addListener(callback: MidiCallback) {
    this.listeners.push(callback);
  }

  public removeListener(callback: MidiCallback) {
    this.listeners = this.listeners.filter(l => l !== callback);
  }
}

export const midiService = new MidiService();