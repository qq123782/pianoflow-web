
import { SongNote, NoteState, SongMetadata } from '../types';
import { Midi } from '@tonejs/midi';

const START_DELAY = 2.0;

type RawNote = { 
  m: number | number[]; 
  d: number; 
};

const seq = (...parts: RawNote[][]): RawNote[] => parts.flat();

const repeat = (notes: RawNote[], times: number): RawNote[] => {
  let res: RawNote[] = [];
  for(let i=0; i<times; i++) res = res.concat(notes);
  return res;
};

const transpose = (notes: RawNote[], semi: number): RawNote[] => {
  return notes.map(n => {
    const newM = Array.isArray(n.m) 
      ? n.m.map(x => x + semi) 
      : n.m + semi;
    return { ...n, m: newM };
  });
};

const harmonize = (notes: RawNote[], interval: number): RawNote[] => {
  return notes.map(n => {
    if (Array.isArray(n.m)) return n; 
    return { ...n, m: [n.m, n.m + interval] };
  });
};

const speed = (notes: RawNote[], factor: number): RawNote[] => {
  return notes.map(n => ({ ...n, d: n.d * factor }));
};

// --- SONG DATA ---
const TWINKLE_A: RawNote[] = [
  { m: 60, d: 1 }, { m: 60, d: 1 }, { m: 67, d: 1 }, { m: 67, d: 1 }, { m: 69, d: 1 }, { m: 69, d: 1 }, { m: 67, d: 2 },
  { m: 65, d: 1 }, { m: 65, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 62, d: 1 }, { m: 60, d: 2 }
];
const TWINKLE_B: RawNote[] = [
  { m: 67, d: 1 }, { m: 67, d: 1 }, { m: 65, d: 1 }, { m: 65, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 2 }
];
const TWINKLE_FULL = seq(
  TWINKLE_A, TWINKLE_B, TWINKLE_B, TWINKLE_A,
  transpose(TWINKLE_A, 12), transpose(TWINKLE_B, 12), transpose(TWINKLE_B, 12), transpose(TWINKLE_A, 12),
  harmonize(TWINKLE_A, 4), harmonize(TWINKLE_B, 3), harmonize(TWINKLE_B, 3), harmonize(TWINKLE_A, 4),
  transpose(TWINKLE_A, -12), transpose(TWINKLE_B, -12), transpose(TWINKLE_B, -12), transpose(TWINKLE_A, -12),
  harmonize(TWINKLE_A, 12), harmonize(TWINKLE_B, 12), harmonize(TWINKLE_B, 12), harmonize(TWINKLE_A, 12)
);

const ODE_A1: RawNote[] = [
  { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 65, d: 1 }, { m: 67, d: 1 }, { m: 67, d: 1 }, { m: 65, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 1 },
  { m: 60, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1.5 }, { m: 62, d: 0.5 }, { m: 62, d: 2 }
];
const ODE_A2: RawNote[] = [
  { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 65, d: 1 }, { m: 67, d: 1 }, { m: 67, d: 1 }, { m: 65, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 1 },
  { m: 60, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 1.5 }, { m: 60, d: 0.5 }, { m: 60, d: 2 }
];
const ODE_B: RawNote[] = [
  { m: 62, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 0.5 }, { m: 65, d: 0.5 }, { m: 64, d: 1 }, { m: 60, d: 1 },
  { m: 62, d: 1 }, { m: 64, d: 0.5 }, { m: 65, d: 0.5 }, { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 2 }
];
const ODE_THEME = seq(ODE_A1, ODE_A2, ODE_B, ODE_A2);
const ODE_FULL = seq(
  ODE_THEME, 
  transpose(ODE_THEME, 12), 
  transpose(ODE_THEME, -12), 
  harmonize(ODE_THEME, -5), 
  speed(ODE_THEME, 0.5), 
  [{ m: [60, 64, 67, 72], d: 4 }]
);

const CANON_BASS = [
  { m: 50, d: 2 }, { m: 45, d: 2 }, { m: 47, d: 2 }, { m: 42, d: 2 },
  { m: 43, d: 2 }, { m: 38, d: 2 }, { m: 43, d: 2 }, { m: 45, d: 2 }
];
const CANON_MELODY = [
  { m: 74, d: 2 }, { m: 72, d: 2 }, { m: 74, d: 2 }, { m: 69, d: 2 },
  { m: 71, d: 2 }, { m: 66, d: 2 }, { m: 71, d: 2 }, { m: 72, d: 2 }
];
const CANON_FULL = seq(
  repeat(CANON_BASS, 4), 
  repeat(seq(CANON_BASS, transpose(CANON_BASS, 12)), 2),
  repeat(CANON_MELODY, 4),
  repeat(harmonize(CANON_MELODY, -5), 4), 
  repeat(transpose(CANON_BASS, -12), 4),
  [{ m: 50, d: 8 }]
);

const HB_THEME: RawNote[] = [
  { m: 67, d: 0.75 }, { m: 67, d: 0.25 }, { m: 69, d: 1 }, { m: 67, d: 1 }, { m: 72, d: 1 }, { m: 71, d: 2 },
  { m: 67, d: 0.75 }, { m: 67, d: 0.25 }, { m: 69, d: 1 }, { m: 67, d: 1 }, { m: 74, d: 1 }, { m: 72, d: 2 },
  { m: 67, d: 0.75 }, { m: 67, d: 0.25 }, { m: 79, d: 1 }, { m: 76, d: 1 }, { m: 72, d: 1 }, { m: 71, d: 1 }, { m: 69, d: 1 },
  { m: 77, d: 0.75 }, { m: 77, d: 0.25 }, { m: 76, d: 1 }, { m: 72, d: 1 }, { m: 74, d: 1 }, { m: 72, d: 2 }
];
const HB_FULL = seq(
  repeat(HB_THEME, 2),
  repeat(transpose(HB_THEME, 12), 2),
  repeat(harmonize(HB_THEME, -12), 2), 
  repeat(transpose(HB_THEME, 2), 2), 
  repeat(transpose(HB_THEME, 4), 2)
);

const JB_CHORUS: RawNote[] = [
  { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 2 },
  { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 2 },
  { m: 64, d: 1 }, { m: 67, d: 1 }, { m: 60, d: 1.5 }, { m: 62, d: 0.5 }, { m: 64, d: 4 },
  { m: 65, d: 1 }, { m: 65, d: 1 }, { m: 65, d: 1.5 }, { m: 65, d: 0.5 },
  { m: 65, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 },
  { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 2 }, { m: 67, d: 2 }
];
const JB_FULL = seq(
  repeat(JB_CHORUS, 4),
  repeat(harmonize(JB_CHORUS, 4), 4), 
  repeat(transpose(JB_CHORUS, 12), 4)
);

const FE_THEME_A: RawNote[] = [
  { m: 76, d: 0.5 }, { m: 75, d: 0.5 }, { m: 76, d: 0.5 }, { m: 75, d: 0.5 }, { m: 76, d: 0.5 }, { m: 71, d: 0.5 }, { m: 74, d: 0.5 }, { m: 72, d: 0.5 }, { m: 69, d: 2 },
  { m: 60, d: 0.5 }, { m: 64, d: 0.5 }, { m: 69, d: 0.5 }, { m: 71, d: 2 },
  { m: 64, d: 0.5 }, { m: 68, d: 0.5 }, { m: 71, d: 0.5 }, { m: 72, d: 2 },
  { m: 64, d: 0.5 }, { m: 76, d: 0.5 }, { m: 75, d: 0.5 }, { m: 76, d: 0.5 }, { m: 75, d: 0.5 }, { m: 76, d: 0.5 }, { m: 71, d: 0.5 }, { m: 74, d: 0.5 }, { m: 72, d: 0.5 }, { m: 69, d: 2 },
  { m: 60, d: 0.5 }, { m: 64, d: 0.5 }, { m: 69, d: 0.5 }, { m: 71, d: 2 },
  { m: 64, d: 0.5 }, { m: 72, d: 0.5 }, { m: 71, d: 0.5 }, { m: 69, d: 4 }
];
const FE_FULL = seq(
  repeat(FE_THEME_A, 4),
  repeat(transpose(FE_THEME_A, 12), 4),
  repeat(transpose(FE_THEME_A, -12), 4),
  repeat(FE_THEME_A, 4)
);

const MLL_A: RawNote[] = [
  { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 2 },
  { m: 62, d: 1 }, { m: 62, d: 1 }, { m: 62, d: 2 },
  { m: 64, d: 1 }, { m: 67, d: 1 }, { m: 67, d: 2 }
];
const MLL_B: RawNote[] = [
  { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 60, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 }, { m: 64, d: 1 },
  { m: 62, d: 1 }, { m: 62, d: 1 }, { m: 64, d: 1 }, { m: 62, d: 1 }, { m: 60, d: 4 }
];
const MLL_FULL = seq(
  repeat(seq(MLL_A, MLL_B), 4),
  repeat(transpose(seq(MLL_A, MLL_B), 12), 4),
  repeat(transpose(seq(MLL_A, MLL_B), -12), 4)
);

const CORN_PATTERN = (bass: number, low: number, high: number): RawNote[] => {
  return [
    { m: [bass, low], d: 0.5 }, { m: high, d: 0.5 }, 
    { m: low, d: 0.5 }, { m: high, d: 0.5 },
    { m: low, d: 0.5 }, { m: high, d: 0.5 },
    { m: low, d: 0.5 }, { m: high, d: 0.5 }
  ];
};

const CORN_INTRO: RawNote[] = repeat([
    { m: 69, d: 0.5 }, { m: 76, d: 0.5 } 
], 16); 

const CORN_FULL = seq(
    CORN_INTRO,
    repeat(CORN_PATTERN(45, 69, 76), 2), 
    repeat(CORN_PATTERN(41, 65, 72), 2), 
    repeat(CORN_PATTERN(43, 67, 74), 2), 
    repeat(CORN_PATTERN(45, 69, 76), 2), 
    repeat(CORN_PATTERN(41, 65, 72), 2), 
    repeat(CORN_PATTERN(43, 67, 74), 2), 
    repeat(CORN_PATTERN(40, 64, 71), 2), 
    repeat(CORN_PATTERN(45, 69, 76), 2), 
    repeat(CORN_PATTERN(57, 81, 88), 2), 
    repeat(CORN_PATTERN(53, 77, 84), 2), 
    [{ m: [45, 57, 69, 76, 81], d: 8 }]
);

const CORN_BACKING: RawNote[] = [
    { m: [33, 45], d: 16 }, // Long drone notes
    { m: [29, 41], d: 16 },
    { m: [31, 43], d: 16 },
    { m: [33, 45], d: 16 },
    { m: [29, 41], d: 16 },
    { m: [31, 43], d: 16 },
    { m: [28, 40], d: 16 },
    { m: [33, 45], d: 16 },
    { m: [45, 57], d: 16 },
    { m: [41, 53], d: 16 },
    { m: [33, 45], d: 8 }
];


const rawToNotes = (raw: RawNote[], bpm: number): SongNote[] => {
  const beatDuration = 60 / bpm;
  let currentTime = START_DELAY;
  let noteCounter = 0;
  const songNotes: SongNote[] = [];
  raw.forEach((n) => {
    const duration = n.d * beatDuration;
    const midis = Array.isArray(n.m) ? n.m : [n.m];
    midis.forEach(midi => {
      songNotes.push({
        id: `n-${noteCounter++}`,
        midi: midi,
        startTime: currentTime,
        duration: duration,
        state: NoteState.Waiting
      });
    });
    currentTime += duration;
  });
  return songNotes;
};

// Generate simple backing track notes synced to start delay
const rawToBacking = (raw: RawNote[], bpm: number): SongNote[] => {
    const beatDuration = 60 / bpm;
    let currentTime = START_DELAY;
    let noteCounter = 0;
    const songNotes: SongNote[] = [];
    
    raw.forEach((n) => {
      const duration = n.d * beatDuration;
      const midis = Array.isArray(n.m) ? n.m : [n.m];
      midis.forEach(midi => {
        songNotes.push({
          id: `bn-${noteCounter++}`,
          midi: midi,
          startTime: currentTime,
          duration: duration,
          state: NoteState.Waiting
        });
      });
      currentTime += duration;
    });
    return songNotes;
  };

export const BUILT_IN_SONGS: SongMetadata[] = [
  {
    id: 'twinkle',
    title: '小星星 (Twinkle Star)',
    artist: '经典儿歌',
    difficulty: 'Easy',
    bpm: 100,
    notes: rawToNotes(TWINKLE_FULL, 100),
    // Simple generated backing: Root note C3 held
    backingNotes: rawToBacking([ { m: 48, d: 8 }, { m: 53, d: 8 }, { m: 55, d: 8 }, { m: 48, d: 8 } ], 100),
    audioPreset: 'Bright'
  },
  {
    id: 'ode',
    title: '欢乐颂 (Ode to Joy)',
    artist: '贝多芬',
    difficulty: 'Medium',
    bpm: 110,
    notes: rawToNotes(ODE_FULL, 110),
    backingNotes: rawToBacking([ { m: 48, d: 16 }, { m: 55, d: 16 }, { m: 48, d: 16 } ], 110),
    audioPreset: 'Concert'
  },
  {
    id: 'canon',
    title: '卡农 (Canon in D)',
    artist: '帕赫贝尔',
    difficulty: 'Easy',
    bpm: 80,
    notes: rawToNotes(CANON_FULL, 80),
    backingNotes: rawToBacking(repeat([{ m: 50, d: 8 }, { m: 45, d: 8 }], 4), 80),
    audioPreset: 'Warm'
  },
  {
    id: 'cornfield',
    title: '星际穿越 (Cornfield Chase)',
    artist: 'Hans Zimmer',
    difficulty: 'Medium',
    bpm: 96,
    notes: rawToNotes(CORN_FULL, 96),
    backingNotes: rawToBacking(CORN_BACKING, 96),
    audioPreset: 'Cosmic' 
  },
  {
    id: 'happy-birthday',
    title: '生日快乐 (Happy Birthday)',
    artist: '传统歌曲',
    difficulty: 'Easy',
    bpm: 100,
    notes: rawToNotes(HB_FULL, 100),
    // Add backing track
    backingNotes: rawToBacking(repeat([{ m: 48, d: 6 }, { m: 55, d: 6 }], 4), 100),
    audioPreset: 'Bright'
  },
  {
    id: 'jingle-bells',
    title: '铃儿响叮当 (Jingle Bells)',
    artist: '皮尔庞特',
    difficulty: 'Easy',
    bpm: 120,
    notes: rawToNotes(JB_FULL, 120),
    // Add backing track
    backingNotes: rawToBacking(repeat([{ m: 48, d: 8 }, { m: 53, d: 8 }], 4), 120),
    audioPreset: 'Standard'
  },
  {
    id: 'fur-elise',
    title: '致爱丽丝 (Für Elise)',
    artist: '贝多芬',
    difficulty: 'Hard',
    bpm: 140,
    notes: rawToNotes(FE_FULL, 140),
    // Add backing track: A minor drone
    backingNotes: rawToBacking(repeat([{ m: 45, d: 8 }, { m: 52, d: 8 }], 8), 140),
    audioPreset: 'Concert'
  },
  {
    id: 'mary-lamb',
    title: '玛丽有只小羔羊 (Mary Had a Lamb)',
    artist: '传统童谣',
    difficulty: 'Easy',
    bpm: 100,
    notes: rawToNotes(MLL_FULL, 100),
    // Add backing track
    backingNotes: rawToBacking(repeat([{ m: 48, d: 8 }, { m: 55, d: 8 }], 4), 100),
    audioPreset: 'Standard'
  }
];

export const parseMidiFile = async (file: File): Promise<SongMetadata> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        if (!e.target?.result) throw new Error("Failed to read file");
        const midi = new Midi(e.target.result as ArrayBuffer);
        let allNotes: any[] = [];
        midi.tracks.forEach(track => {
          track.notes.forEach(n => {
             allNotes.push({
               midi: n.midi,
               time: n.time,
               duration: n.duration,
             });
          });
        });
        allNotes.sort((a, b) => a.time - b.time);
        const notes: SongNote[] = allNotes.map((n, i) => ({
          id: `midi-${i}`,
          midi: n.midi,
          startTime: n.time + START_DELAY, 
          duration: n.duration,
          state: NoteState.Waiting
        }));
        const duration = midi.duration;
        const estimatedBpm = midi.header.tempos.length > 0 ? Math.round(midi.header.tempos[0].bpm) : 120;
        const notesPerSecond = notes.length / duration;
        let difficulty: 'Easy' | 'Medium' | 'Hard' = 'Medium';
        if (notesPerSecond < 2) difficulty = 'Easy';
        if (notesPerSecond > 5) difficulty = 'Hard';
        resolve({
          id: `custom-${Date.now()}`,
          title: file.name.replace('.mid', '').replace('.midi', ''),
          artist: '导入的 MIDI',
          difficulty,
          bpm: estimatedBpm,
          notes,
          audioPreset: 'Standard'
        });
      } catch (err) {
        reject(err);
      }
    };
    reader.readAsArrayBuffer(file);
  });
};

export const generateSong = (): SongNote[] => {
  return BUILT_IN_SONGS[0].notes || [];
};
