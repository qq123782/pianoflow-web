
import React, { useState, useRef, useEffect } from 'react';
import { GameStats, ThemeMode } from '../types';
import { Play, Pause, RotateCcw, GraduationCap, Music, Sparkles, LibraryBig, Footprints, GripVertical, ChevronDown, Move, Sliders, Layers, Bot, Maximize, Minimize, Lock, Unlock, Palette, Zap, Moon, Citrus, Cloud } from 'lucide-react';

interface UIOverlayProps {
  isPlaying: boolean;
  isWaitMode: boolean;
  isBackingTrackOn: boolean;
  isAutoPlay: boolean; 
  stats: GameStats;
  theme: ThemeMode;
  onTogglePlay: () => void;
  onToggleWaitMode: () => void;
  onToggleBackingTrack: () => void;
  onToggleAutoPlay: () => void;
  onReset: () => void;
  onToggleAI: () => void;
  onAnalyze: () => void;
  onToggleLibrary: () => void;
  onToggleSettings: () => void;
  onToggleTheme: () => void;
  isAiOpen: boolean;
  isLibraryOpen: boolean;
}

export const UIOverlay: React.FC<UIOverlayProps> = ({ 
  isPlaying, 
  isWaitMode,
  isBackingTrackOn,
  isAutoPlay,
  stats, 
  theme,
  onTogglePlay, 
  onToggleWaitMode,
  onToggleBackingTrack,
  onToggleAutoPlay,
  onReset,
  onToggleAI,
  onAnalyze,
  onToggleLibrary,
  onToggleSettings,
  onToggleTheme,
  isAiOpen,
  isLibraryOpen
}) => {
  const hasStarted = stats.score > 0 || stats.hits.miss > 0;

  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLocked, setIsLocked] = useState(false); 
  
  const dragRef = useRef({
    startX: 0,
    startY: 0,
    initialX: 0,
    initialY: 0
  });

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message} (${err.name})`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  const handleLock = () => {
      if (!isFullscreen) {
          toggleFullscreen();
      }
      setIsLocked(true);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).closest('button')) return;
    setIsDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initialX: position.x,
      initialY: position.y
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    const dx = e.clientX - dragRef.current.startX;
    const dy = e.clientY - dragRef.current.startY;
    setPosition({
      x: dragRef.current.initialX + dx,
      y: dragRef.current.initialY + dy
    });
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    e.currentTarget.releasePointerCapture(e.pointerId);
  };

  if (isLocked) {
      return (
        <div className="absolute inset-0 pointer-events-none z-50">
             <div className="absolute top-4 right-4 pointer-events-auto animate-in fade-in duration-500">
                <button 
                    onClick={() => setIsLocked(false)}
                    className="p-3 bg-black/20 hover:bg-black/60 backdrop-blur-md rounded-full text-white/30 hover:text-white transition-all shadow-xl border border-white/5 hover:border-white/20"
                    title="解锁界面"
                >
                    <Unlock size={24} />
                </button>
             </div>
        </div>
      )
  }

  const getThemeIcon = () => {
      switch(theme) {
          case 'neon': return <Zap size={20} />;
          case 'fruit': return <Citrus size={20} />;
          case 'starry': return <Moon size={20} />;
          case 'dream': return <Cloud size={20} />;
          default: return <Palette size={20} />;
      }
  };

  const getThemeStyle = () => {
      switch(theme) {
          case 'neon': return 'bg-purple-900/50 border-purple-500 text-purple-300 shadow-purple-500/30';
          case 'fruit': return 'bg-orange-500/20 border-orange-500 text-orange-300 shadow-orange-500/30';
          case 'starry': return 'bg-blue-900/50 border-blue-400 text-yellow-200 shadow-blue-500/30';
          case 'dream': return 'bg-pink-500/20 border-pink-400 text-pink-200 shadow-pink-500/30';
          default: return 'bg-slate-800 border-slate-700 text-slate-300 hover:text-white';
      }
  };

  const getThemeLabel = () => {
      switch(theme) {
          case 'neon': return '赛博光刃';
          case 'fruit': return '水果道场';
          case 'starry': return '梵高星空';
          case 'dream': return '梦幻光斑';
          default: return '深空经典';
      }
  };

  return (
    <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-4 md:p-8 z-10 overflow-hidden">
      
      {/* Top Bar: Logo & Stats */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pointer-events-none transition-opacity duration-300">
        
        <div className="bg-slate-900/40 backdrop-blur-xl p-4 rounded-2xl border border-white/10 shadow-2xl flex items-center gap-3 transition-transform hover:scale-105">
          <div className="bg-sky-500/20 p-2 rounded-lg text-sky-400">
            <Music size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-teal-400">
              PianoFlow
            </h1>
            <div className="text-[10px] text-slate-400 font-mono uppercase tracking-widest">互动钢琴教学</div>
          </div>
        </div>

        <div className="flex gap-3 pointer-events-none">
           <StatCard label="得分" value={stats.score.toLocaleString()} color="text-white" />
           <StatCard label="连击" value={stats.streak} color="text-emerald-400" />
           <StatCard 
             label="准确率" 
             value={`${stats.hits.perfect + stats.hits.good + stats.hits.miss > 0 
               ? Math.round(((stats.hits.perfect + stats.hits.good) / (stats.hits.perfect + stats.hits.good + stats.hits.miss)) * 100) 
               : 100}%`} 
             color="text-sky-400" 
           />
        </div>
      </div>

      {/* Center: Play Prompt */}
      <div className="flex-1 flex items-center justify-center pointer-events-none">
          {!isPlaying && (
            <div className="flex flex-col items-center gap-6 pointer-events-auto">
              <div 
                onClick={onTogglePlay}
                className="group relative cursor-pointer"
              >
                <div className="absolute inset-0 bg-sky-500/30 blur-3xl rounded-full animate-pulse" />
                <div className="relative bg-slate-900/60 backdrop-blur-md border border-sky-500/30 p-8 rounded-3xl flex flex-col items-center gap-4 transition transform group-hover:scale-105 group-hover:border-sky-400">
                   <div className="w-20 h-20 bg-sky-500 rounded-full flex items-center justify-center shadow-lg shadow-sky-500/40 group-hover:shadow-sky-500/60 transition-all">
                      <Play size={40} className="text-white ml-2" />
                   </div>
                   <div className="text-center">
                     <div className="text-2xl font-bold text-white tracking-tight">开始练习</div>
                     <div className="text-sm text-sky-200/70 mt-1">点击或按空格键</div>
                   </div>
                </div>
              </div>
              {hasStarted && (
                <button
                  onClick={onAnalyze}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-xl font-medium shadow-lg shadow-indigo-900/50 transition-all transform hover:-translate-y-1 border border-indigo-400/20"
                >
                  <Sparkles size={18} />
                  <span>AI 演奏分析</span>
                </button>
              )}
            </div>
          )}
      </div>

      {/* Footer: Draggable Controls */}
      <div className="absolute bottom-8 left-0 right-0 flex justify-center pointer-events-none">
        <div 
          className="pointer-events-auto touch-none relative transition-transform duration-75 ease-out"
          style={{ transform: `translate(${position.x}px, ${position.y}px)` }}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
        >
          <div className={`
            flex items-center gap-2 bg-slate-900/80 backdrop-blur-2xl rounded-full border border-white/10 shadow-2xl transition-all duration-300
            ${isCollapsed ? 'p-2 w-14 h-14' : 'p-3 pr-5'}
          `}>
             {!isCollapsed && (
               <div className="cursor-grab active:cursor-grabbing p-2 text-slate-500 hover:text-slate-300 flex items-center justify-center">
                 <GripVertical size={20} />
               </div>
             )}

             {isCollapsed ? (
               <button 
                 onClick={(e) => { e.stopPropagation(); setIsCollapsed(false); }}
                 className="w-full h-full flex items-center justify-center text-sky-400 hover:text-white"
               >
                 <Move size={20} />
               </button>
             ) : (
               <>
                 <ControlButton onClick={onReset} icon={<RotateCcw size={22} />} label="重置" />
                 
                 <div className="w-px h-8 bg-slate-700/50 mx-1"></div>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleBackingTrack(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg border ${
                     isBackingTrackOn 
                       ? 'bg-purple-600/20 border-purple-500 text-purple-400 shadow-purple-500/20' 
                       : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
                   }`}
                   title={isBackingTrackOn ? "背景伴奏：开启" : "背景伴奏：关闭"}
                 >
                   <Layers size={22} />
                 </button>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleAutoPlay(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg border ${
                     isAutoPlay 
                       ? 'bg-pink-600/20 border-pink-500 text-pink-400 shadow-pink-500/20 animate-pulse' 
                       : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
                   }`}
                   title={isAutoPlay ? "AI 托管：开启" : "AI 托管：关闭"}
                 >
                   <Bot size={22} />
                 </button>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleWaitMode(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg border ${
                     isWaitMode 
                       ? 'bg-amber-500/20 border-amber-500 text-amber-400 shadow-amber-500/20' 
                       : 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700'
                   }`}
                   title={isWaitMode ? "等待模式：开启" : "等待模式：关闭"}
                 >
                   <Footprints size={22} />
                 </button>

                 <div className="w-px h-8 bg-slate-700/50 mx-1"></div>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onTogglePlay(); }}
                   className={`w-16 h-16 rounded-full flex items-center justify-center transition-all shadow-lg transform hover:scale-105 hover:shadow-xl mx-2 ${
                     isPlaying 
                       ? 'bg-amber-500 hover:bg-amber-400 text-white shadow-amber-500/30' 
                       : 'bg-emerald-500 hover:bg-emerald-400 text-white shadow-emerald-500/30'
                   }`}
                   title={isPlaying ? "暂停" : "开始"}
                 >
                   {isPlaying ? <Pause size={28} fill="currentColor" /> : <Play size={28} fill="currentColor" className="ml-1" />}
                 </button>

                 <div className="w-px h-8 bg-slate-700/50 mx-1"></div>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleLibrary(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg ${
                     isLibraryOpen 
                       ? 'bg-amber-600 text-white shadow-amber-600/40' 
                       : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white border border-slate-700'
                   }`}
                   title="曲库"
                 >
                   <LibraryBig size={22} />
                 </button>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleAI(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all shadow-lg ${
                     isAiOpen 
                       ? 'bg-sky-600 text-white shadow-sky-600/40' 
                       : 'bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white border border-slate-700'
                   }`}
                   title="AI 导师"
                 >
                   <GraduationCap size={22} />
                 </button>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleSettings(); }}
                   className="w-12 h-12 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full flex items-center justify-center transition border border-slate-700 hover:border-slate-600"
                   title="调音台"
                 >
                   <Sliders size={22} />
                 </button>

                 <div className="w-px h-8 bg-slate-700/50 mx-1"></div>

                 <button 
                   onClick={(e) => { e.stopPropagation(); onToggleTheme(); }}
                   className={`w-12 h-12 rounded-full flex items-center justify-center transition-all border ${getThemeStyle()}`}
                   title={`切换主题：${getThemeLabel()}`}
                 >
                   {getThemeIcon()}
                 </button>
                 
                 <ControlButton onClick={toggleFullscreen} icon={isFullscreen ? <Minimize size={22} /> : <Maximize size={22} />} label="全屏模式" />
                 <ControlButton onClick={handleLock} icon={<Lock size={22} className={isLocked ? 'text-rose-400' : ''} />} label="沉浸锁定 (隐藏UI)" />

                 <button 
                   onClick={(e) => { e.stopPropagation(); setIsCollapsed(true); }}
                   className="ml-2 p-2 text-slate-500 hover:text-white rounded-full hover:bg-slate-800/50"
                   title="收起工具栏"
                 >
                   <ChevronDown size={20} />
                 </button>
               </>
             )}
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, color }: { label: string, value: string | number, color: string }) => (
  <div className="bg-slate-900/60 backdrop-blur-lg px-5 py-3 rounded-2xl border border-white/5 min-w-[110px] shadow-lg">
    <div className="text-slate-500 text-[10px] font-bold uppercase tracking-wider mb-1">{label}</div>
    <div className={`text-2xl font-mono font-bold ${color} drop-shadow-md`}>{value}</div>
  </div>
);

const ControlButton = ({ onClick, icon, label }: { onClick: (e: any) => void, icon: React.ReactNode, label: string }) => (
  <button 
    onClick={(e) => { e.stopPropagation(); onClick(e); }}
    className="w-12 h-12 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-full flex items-center justify-center transition border border-slate-700 hover:border-slate-600"
    title={label}
  >
    {icon}
  </button>
);
