
import React, { useState, useEffect } from 'react';
import { SongMetadata, SongNote, NoteState } from '../types';
import { BUILT_IN_SONGS, parseMidiFile } from '../services/songLoader';
import { audioService } from '../services/audioService';
import { Music, Upload, X, Play, FileMusic, BarChart, Heart, Volume2, Square, Globe, Search, Loader2, ArrowRight, CheckCircle2, Sparkles, Youtube } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import * as Tone from 'tone';

interface SongLibraryProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSong: (song: SongMetadata) => void;
  savedSongs?: SongMetadata[];
}

// Types for the "Detective Mode"
interface SearchedSongInfo {
  title: string;
  artist: string;
  bpm: number;
  key: string;
  genre: string;
  description: string;
  chords: string; // Basic progression description
  difficulty: 'Easy' | 'Medium' | 'Hard';
  videoUrl?: string; // Added video link for verification
}

export const SongLibrary: React.FC<SongLibraryProps> = ({ isOpen, onClose, onSelectSong, savedSongs = [] }) => {
  const [activeTab, setActiveTab] = useState<'local' | 'search'>('local');
  const [isDragging, setIsDragging] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [previewId, setPreviewId] = useState<string | null>(null);

  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResult, setSearchResult] = useState<SearchedSongInfo | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStatus, setGenerationStatus] = useState('');

  // Stop preview when library closes
  useEffect(() => {
    if (!isOpen) {
        audioService.stopAll();
        setPreviewId(null);
    }
  }, [isOpen]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      await processFile(e.target.files[0]);
    }
    e.target.value = '';
  };

  const processFile = async (file: File) => {
    setUploadError(null);
    try {
      const song = await parseMidiFile(file);
      onSelectSong(song);
      onClose();
    } catch (err) {
      console.error(err);
      setUploadError("无效的 MIDI 文件。" + (err instanceof Error ? err.message : "未知错误"));
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await processFile(e.dataTransfer.files[0]);
    }
  };

  const togglePreview = (e: React.MouseEvent, song: SongMetadata) => {
    e.stopPropagation(); 
    if (previewId === song.id) {
        audioService.stopAll();
        setPreviewId(null);
    } else {
        if (song.notes) {
            setPreviewId(song.id);
            // Apply song preset if available for preview
            if(song.audioPreset) audioService.applyPreset(song.audioPreset);
            audioService.previewSong(song.notes, song.backingNotes); // Include backing in preview
        }
    }
  };

  const getDifficultyColor = (d: string) => {
    switch(d) {
      case 'Easy': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'Medium': return 'text-amber-400 bg-amber-400/10 border-amber-400/20';
      case 'Hard': return 'text-rose-400 bg-rose-400/10 border-rose-400/20';
      default: return 'text-slate-400';
    }
  };

  // --- AI LOGIC ---

  const performGlobalSearch = async () => {
      if (!searchQuery.trim()) return;
      setIsSearching(true);
      setSearchResult(null);
      setUploadError(null);
      
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
          
          const prompt = `
            You are a music detective. The user wants to play "${searchQuery}" on piano.
            
            Step 1: SEARCH using the attached tool for the ORIGINAL song details (BPM, Key, Artist, Genre) AND a valid YouTube or audio link for verification.
            Step 2: Return a strict JSON object with metadata. Do NOT generate notes yet.
            
            Required JSON Structure:
            {
                "title": "Official Song Title",
                "artist": "Original Artist",
                "bpm": 120,
                "key": "C Major",
                "genre": "Pop Ballad / Rock / etc",
                "chords": "C - G - Am - F",
                "description": "A brief 1-sentence description of the song's vibe and structure.",
                "difficulty": "Medium",
                "videoUrl": "A valid YouTube URL found in search results (e.g. https://www.youtube.com/...)"
            }
          `;

          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: { 
                tools: [{ googleSearch: {} }], 
                // NOTE: Cannot use responseMimeType: "application/json" with googleSearch tool
            }
          });

          const text = response.text;
          if (!text) throw new Error("No response");
          
          // Robust JSON parsing
          let cleanJson = text.replace(/```json\s*|\s*```/g, '').trim();
          cleanJson = cleanJson.replace(/```/g, '').trim(); 
          
          // Strip comments (Single line // and Multi line /* */)
          cleanJson = cleanJson.replace(/\/\/.*$/gm, '');
          cleanJson = cleanJson.replace(/\/\*[\s\S]*?\*\//g, '');

          // Fallback to extract JSON object if text surrounds it
          const jsonStart = cleanJson.indexOf('{');
          const jsonEnd = cleanJson.lastIndexOf('}');
          if (jsonStart !== -1 && jsonEnd !== -1) {
            cleanJson = cleanJson.substring(jsonStart, jsonEnd + 1);
          }

          // FIX: Replace literal newlines/tabs which are invalid in JSON strings (Bad Control Character)
          // replacing them with spaces ensures JSON.parse doesn't crash
          cleanJson = cleanJson.replace(/[\x00-\x1F]+/g, " ");

          const data = JSON.parse(cleanJson);
          
          setSearchResult(data);

      } catch (e) {
          console.error("Search failed", e);
          setUploadError("搜谱失败，请检查网络或重试。");
      } finally {
          setIsSearching(false);
      }
  };

  const generateFullSong = async () => {
      if (!searchResult) return;
      setIsGenerating(true);
      setGenerationStatus('正在编排主旋律...');
      
      try {
          const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

          // Progress updates simulation
          setTimeout(() => setGenerationStatus('正在生成原版风格伴奏...'), 2000);
          setTimeout(() => setGenerationStatus('正在优化钢琴指法...'), 4500);

          const systemInstruction = `
            You are an expert Piano Arranger. 
            Create a "Full Song" arrangement based on the specific metadata provided.
            
            **METADATA (STRICTLY FOLLOW)**:
            - Title: ${searchResult.title}
            - Artist: ${searchResult.artist}
            - BPM: ${searchResult.bpm}
            - Key: ${searchResult.key}
            - Genre: ${searchResult.genre}
            - Chords: ${searchResult.chords}

            **ARRANGEMENT RULES**:
            1. **Melody (Right Hand)**: Accurate to the original song.
            2. **Backing (Left Hand/Band)**: MATCH THE GENRE. 
               - If Rock: Driving 8th notes. 
               - If Ballad: Flowing arpeggios.
               - If Epic: Deep bass drones.
            3. **Duration**: Generate at least the Verse + Chorus (approx 1-2 mins).
            4. **Format**: Compact JSON Arrays \`["Note", Duration]\`.

            **OUTPUT JSON**:
            {
              "title": "${searchResult.title}",
              "description": "${searchResult.description}",
              "bpm": ${searchResult.bpm},
              "audioPreset": "Standard", 
              "notes": [ ["C4", 1], ... ],
              "backingNotes": [ ["C2", 2], ... ]
            }
          `;

          const response = await ai.models.generateContent({
              model: 'gemini-2.5-flash',
              contents: `Generate the full arrangement now.`,
              config: {
                  systemInstruction,
                  temperature: 0.4, // Lower temperature for musical accuracy
                  maxOutputTokens: 8192
              }
          });

          const rawText = response.text;
          if (!rawText) throw new Error("Generation failed");

          // Clean and Parse JSON (Reuse logic from AITeacherSidebar)
          let cleanJson = rawText.replace(/```json\s*|\s*```/g, '').trim();
          cleanJson = cleanJson.replace(/```/g, '').trim();
          
          // Remove comments
          cleanJson = cleanJson.replace(/\/\/.*$/gm, ''); 
          cleanJson = cleanJson.replace(/\/\*[\s\S]*?\*\//g, '');

          // Find braces
          const jStart = cleanJson.indexOf('{');
          const jEnd = cleanJson.lastIndexOf('}');
          if (jStart !== -1 && jEnd !== -1) {
            cleanJson = cleanJson.substring(jStart, jEnd + 1);
          }

          // Basic repair for trailing commas
          cleanJson = cleanJson.replace(/,\s*([\]}])/g, '$1'); 
          
          // FIX: Remove Bad Control Characters
          cleanJson = cleanJson.replace(/[\x00-\x1F]+/g, " ");

          const parsed = JSON.parse(cleanJson);

          // Convert compact arrays to SongNote[]
          const beatDur = 60 / parsed.bpm;
          let time = 2.0; // 2s start delay
          
          const convertNotes = (list: any[], prefix: string): SongNote[] => {
              if (!list) return [];
              let t = time;
              return list.map((item, i) => {
                  const n = Array.isArray(item) ? item[0] : item.note;
                  const d = Array.isArray(item) ? Number(item[1]) : item.duration;
                  const durSec = d * beatDur;
                  const noteObj = {
                      id: `${prefix}-${i}`,
                      midi: n === 'REST' ? 0 : Tone.Frequency(n).toMidi(),
                      startTime: t,
                      duration: durSec,
                      state: NoteState.Waiting
                  };
                  t += durSec;
                  // Filter out rests for final array, but keep time increment
                  return n === 'REST' ? null : noteObj;
              }).filter(n => n !== null) as SongNote[];
          };

          const newSong: SongMetadata = {
              id: `global-${Date.now()}`,
              title: parsed.title,
              artist: searchResult.artist,
              bpm: parsed.bpm,
              difficulty: searchResult.difficulty,
              notes: convertNotes(parsed.notes, 'melody'),
              backingNotes: convertNotes(parsed.backingNotes, 'backing'),
              audioPreset: parsed.audioPreset || 'Standard'
          };
          
          // Auto-select appropriate preset based on genre if not returned
          const g = searchResult.genre.toLowerCase();
          if (g.includes('rock')) newSong.audioPreset = 'Bright';
          if (g.includes('ballad')) newSong.audioPreset = 'Warm';
          if (g.includes('epic') || g.includes('soundtrack')) newSong.audioPreset = 'Cosmic';
          if (g.includes('classical')) newSong.audioPreset = 'Concert';

          onSelectSong(newSong);
          onClose();

      } catch (e) {
          console.error("Generation Error", e);
          setUploadError("生成失败，AI 返回的数据格式可能有误，请重试。");
      } finally {
          setIsGenerating(false);
      }
  };

  // --- RENDER HELPERS ---

  const renderSongItem = (song: SongMetadata, isSaved = false) => {
    const isPreviewing = previewId === song.id;
    return (
        <div 
            key={song.id}
            onClick={() => { onSelectSong(song); onClose(); }}
            className={`relative overflow-hidden rounded-xl p-3 cursor-pointer group transition-all shadow-sm hover:shadow-md border ${
                isPreviewing 
                ? 'bg-slate-800/80 border-sky-500/50 ring-1 ring-sky-500/30' 
                : 'bg-slate-800/50 hover:bg-slate-800 border-slate-700/50 hover:border-sky-500/30'
            }`}
        >
            {isPreviewing && (
                <div className="absolute inset-0 bg-sky-500/5 pointer-events-none animate-pulse" />
            )}
            <div className="flex justify-between items-start relative z-10">
                <div className="flex items-center gap-3">
                    <button 
                        onClick={(e) => togglePreview(e, song)}
                        className={`w-10 h-10 rounded-lg flex items-center justify-center transition-all ${
                            isPreviewing 
                            ? 'bg-sky-500 text-white shadow-lg shadow-sky-500/40 scale-105' 
                            : 'bg-slate-700 text-slate-400 hover:text-sky-400 hover:bg-slate-600'
                        }`}
                        title="试听"
                    >
                        {isPreviewing ? <Square size={16} fill="currentColor" /> : <Volume2 size={20} />}
                    </button>
                    <div>
                        <div className={`font-bold transition-colors ${isPreviewing ? 'text-sky-400' : 'text-slate-200 group-hover:text-white'}`}>
                            {song.title}
                        </div>
                        <div className="text-xs text-slate-500">{song.artist}</div>
                    </div>
                </div>
                <div className={`text-[10px] px-2 py-1 rounded border ${
                    isSaved ? 'text-slate-400 bg-slate-400/5 border-slate-400/10' : getDifficultyColor(song.difficulty)
                }`}>
                    {isSaved ? `${song.notes?.length || 0} 音符` : song.difficulty}
                </div>
            </div>
            <div className="mt-3 flex items-center gap-4 text-xs text-slate-500 relative z-10">
                <span className="flex items-center gap-1"><BarChart size={12} /> {song.bpm} BPM</span>
                <span className={`flex items-center gap-1 transition-colors ml-auto font-medium ${isSaved ? 'text-rose-500/0 group-hover:text-rose-400' : 'text-sky-500/0 group-hover:text-sky-400'}`}>
                    开始练习 <Play size={10} className="ml-0.5" fill="currentColor" />
                </span>
            </div>
        </div>
    );
  };

  return (
    <div 
      className={`fixed inset-y-0 left-0 w-96 bg-slate-900/95 backdrop-blur-xl border-r border-slate-700 shadow-2xl transform transition-transform duration-300 ease-in-out z-50 flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-700 bg-slate-800/50">
        <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2 text-sky-400">
            <FileMusic size={24} />
            <div>
                <h2 className="font-bold text-lg leading-none">曲库</h2>
            </div>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X size={20} />
            </button>
        </div>

        {/* Tabs */}
        <div className="flex p-1 bg-slate-900 rounded-lg">
          <button 
            onClick={() => setActiveTab('local')}
            className={`flex-1 py-1.5 text-xs font-bold uppercase tracking-wider rounded-md flex items-center justify-center gap-2 transition-all ${activeTab === 'local' ? 'bg-slate-700 text-white shadow' : 'text-slate-500 hover:text-slate-300'}`}
          >
            本地曲目
          </button>
          <button 
            onClick={() => setActiveTab('search')}
            className={`flex-1 py-1.5 text-xs font-bold uppercase tracking-wider rounded-md flex items-center justify-center gap-2 transition-all ${activeTab === 'search' ? 'bg-indigo-600 text-white shadow' : 'text-slate-500 hover:text-slate-300'}`}
          >
            <Globe size={12} /> 全球搜谱
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-700 relative">
        
        {activeTab === 'local' ? (
            <div className="p-4 space-y-6">
                {savedSongs.length > 0 && (
                    <div>
                        <h3 className="text-xs font-bold text-rose-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <Heart size={12} className="fill-current" /> 我的收藏
                        </h3>
                        <div className="space-y-3">
                            {savedSongs.map(song => renderSongItem(song, true))}
                        </div>
                        <div className="border-b border-slate-800 mt-6"></div>
                    </div>
                )}
                <div>
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">经典曲目</h3>
                <div className="space-y-3">
                    {BUILT_IN_SONGS.map(song => renderSongItem(song, false))}
                </div>
                </div>
                <div className="pt-4">
                    <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">自定义导入</h3>
                    <div 
                        className={`border-2 border-dashed rounded-xl p-6 text-center transition-colors cursor-pointer ${isDragging ? 'border-sky-500 bg-sky-500/10' : 'border-slate-700 hover:border-slate-600 hover:bg-slate-800/50'}`}
                        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                        onDragLeave={() => setIsDragging(false)}
                        onDrop={handleDrop}
                        onClick={() => document.getElementById('midi-upload')?.click()}
                    >
                        <input 
                            id="midi-upload" 
                            type="file" 
                            accept=".mid,.midi" 
                            className="hidden" 
                            onChange={handleFileChange}
                        />
                        <Upload className="mx-auto text-slate-400 mb-2" size={24} />
                        <p className="text-sm text-slate-300 font-medium">上传 MIDI 文件</p>
                        <p className="text-xs text-slate-500 mt-1">拖拽或点击浏览</p>
                        {uploadError && <p className="text-xs text-red-400 mt-2">{uploadError}</p>}
                    </div>
                </div>
            </div>
        ) : (
            // SEARCH TAB CONTENT
            <div className="p-4 space-y-6">
                
                {/* Search Box */}
                <div className="space-y-2">
                    <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">搜索全球乐谱</h3>
                    <div className="relative">
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && performGlobalSearch()}
                            placeholder="输入歌名 (如: 晴天 周杰伦)..."
                            className="w-full bg-slate-800 border border-slate-600 text-white rounded-lg pl-10 pr-4 py-3 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition text-sm placeholder-slate-500"
                        />
                        <Search className="absolute left-3 top-3.5 text-slate-500" size={16} />
                        <button 
                            onClick={performGlobalSearch}
                            disabled={!searchQuery.trim() || isSearching || isGenerating}
                            className="absolute right-2 top-2 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 text-white rounded text-xs font-bold transition"
                        >
                            {isSearching ? <Loader2 size={14} className="animate-spin" /> : '搜索'}
                        </button>
                    </div>
                    <p className="text-[10px] text-slate-500 pl-1">
                        * AI 将联网搜索原版 BPM、调式与和弦风格，为您还原最真实的演奏体验。
                    </p>
                </div>

                {/* Search Result Card (Confirmation Step) */}
                {searchResult && !isGenerating && (
                    <div className="bg-slate-800/80 border border-indigo-500/30 rounded-xl p-4 shadow-xl animate-in fade-in slide-in-from-bottom-4">
                        <div className="flex items-start gap-3 mb-4">
                            <div className="bg-indigo-500/20 p-2 rounded-lg text-indigo-400">
                                <Globe size={24} />
                            </div>
                            <div className="flex-1">
                                <h3 className="font-bold text-lg text-white leading-tight">{searchResult.title}</h3>
                                <div className="text-sm text-slate-400 mb-1">{searchResult.artist}</div>
                                {searchResult.videoUrl && (
                                     <a 
                                       href={searchResult.videoUrl}
                                       target="_blank"
                                       rel="noreferrer"
                                       className="inline-flex items-center gap-1.5 px-2 py-1 bg-red-600/20 hover:bg-red-600/30 border border-red-600/30 rounded text-[10px] text-red-400 transition-colors"
                                     >
                                        <Youtube size={12} /> 试听原曲 (YouTube)
                                     </a>
                                )}
                            </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-2 mb-4">
                            <div className="bg-slate-900/50 p-2 rounded border border-slate-700/50">
                                <div className="text-[10px] text-slate-500 uppercase font-bold">BPM</div>
                                <div className="text-sm text-emerald-400 font-mono">{searchResult.bpm}</div>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded border border-slate-700/50">
                                <div className="text-[10px] text-slate-500 uppercase font-bold">Key</div>
                                <div className="text-sm text-sky-400 font-mono">{searchResult.key}</div>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded border border-slate-700/50 col-span-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold">Style / Genre</div>
                                <div className="text-sm text-slate-300">{searchResult.genre}</div>
                            </div>
                            <div className="bg-slate-900/50 p-2 rounded border border-slate-700/50 col-span-2">
                                <div className="text-[10px] text-slate-500 uppercase font-bold">Core Chords</div>
                                <div className="text-xs text-amber-400 font-mono truncate">{searchResult.chords}</div>
                            </div>
                        </div>

                        <div className="text-xs text-slate-400 italic mb-4 border-l-2 border-slate-600 pl-2">
                            "{searchResult.description}"
                        </div>

                        <button
                            onClick={generateFullSong}
                            className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/50 transition-transform hover:scale-[1.02] active:scale-100"
                        >
                            <Sparkles size={18} /> 确认并生成演奏谱
                        </button>
                    </div>
                )}

                {/* Loading / Generating State */}
                {(isSearching || isGenerating) && (
                    <div className="flex flex-col items-center justify-center py-8 text-center animate-in fade-in">
                        <div className="relative w-16 h-16 mb-4">
                             <div className="absolute inset-0 border-4 border-slate-700 rounded-full"></div>
                             <div className="absolute inset-0 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                             <Music className="absolute inset-0 m-auto text-indigo-400 animate-pulse" size={24} />
                        </div>
                        <div className="text-indigo-400 font-bold text-lg mb-1">
                            {isSearching ? '正在全网搜索...' : 'AI 作曲家工作中...'}
                        </div>
                        <div className="text-xs text-slate-500 max-w-[200px] mx-auto leading-relaxed">
                            {isSearching 
                                ? '正在分析原版音频特征、BPM与和弦进行...' 
                                : generationStatus || '正在编排左右手声部与背景伴奏...'}
                        </div>
                    </div>
                )}

                {/* Empty State / Prompt */}
                {!searchResult && !isSearching && !isGenerating && (
                    <div className="text-center py-12 opacity-50 pointer-events-none">
                        <Globe className="mx-auto text-slate-600 mb-3" size={48} />
                        <p className="text-sm text-slate-500">输入歌名，让 AI 为您定制<br/>原汁原味的演奏乐谱</p>
                    </div>
                )}
                
                 {uploadError && (
                    <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-lg text-xs text-rose-400 text-center">
                        {uploadError}
                    </div>
                )}
            </div>
        )}

      </div>
    </div>
  );
};
