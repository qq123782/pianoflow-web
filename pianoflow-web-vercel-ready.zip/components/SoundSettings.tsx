
import React, { useState, useEffect } from 'react';
import { audioService, AudioPresetName } from '../services/audioService';
import { X, Sliders, Speaker, Zap, Music, Sparkles, Sun, Moon } from 'lucide-react';

interface SoundSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SoundSettings: React.FC<SoundSettingsProps> = ({ isOpen, onClose }) => {
  // Local state for UI sync
  const [eq, setEq] = useState({ low: 0, mid: 0, high: 0 });
  const [reverb, setReverb] = useState(0.25);
  const [activePreset, setActivePreset] = useState<AudioPresetName | 'Custom'>('Standard');

  useEffect(() => {
    // Sync with service on open
    if (isOpen) {
       const s = audioService.currentSettings;
       setEq({ low: s.eqLow, mid: s.eqMid, high: s.eqHigh });
       setReverb(s.reverbWet);
    }
  }, [isOpen]);

  const handlePresetClick = (name: AudioPresetName) => {
    audioService.applyPreset(name);
    setActivePreset(name);
    
    // Update local sliders to match preset
    const s = audioService.currentSettings;
    setEq({ low: s.eqLow, mid: s.eqMid, high: s.eqHigh });
    setReverb(s.reverbWet);
  };

  const handleEQChange = (band: 'low' | 'mid' | 'high', val: number) => {
    const newEq = { ...eq, [band]: val };
    setEq(newEq);
    audioService.setEQ(newEq.low, newEq.mid, newEq.high);
    setActivePreset('Custom');
  };

  const handleReverbChange = (val: number) => {
    setReverb(val);
    audioService.setReverb(val);
    setActivePreset('Custom');
  };

  const PRESET_BUTTONS: { id: AudioPresetName, label: string, icon: any, color: string }[] = [
    { id: 'Standard', label: '标准', icon: Music, color: 'bg-slate-600' },
    { id: 'Concert', label: '音乐厅', icon: Speaker, color: 'bg-indigo-500' },
    { id: 'Warm', label: '温暖', icon: Moon, color: 'bg-amber-600' },
    { id: 'Bright', label: '明亮', icon: Sun, color: 'bg-sky-500' },
    { id: 'Cosmic', label: '星际', icon: Sparkles, color: 'bg-purple-600' },
  ];

  return (
    <div 
      className={`fixed inset-y-0 right-0 w-80 bg-slate-900/95 backdrop-blur-xl border-l border-slate-700 shadow-2xl transform transition-transform duration-300 ease-in-out z-[60] flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-800/50">
        <div className="flex items-center gap-2 text-indigo-400">
          <Sliders size={24} />
          <div>
            <h2 className="font-bold text-lg leading-none">调音台</h2>
            <span className="text-xs text-slate-400">Sound Settings</span>
          </div>
        </div>
        <button onClick={onClose} className="text-slate-400 hover:text-white transition">
          <X size={20} />
        </button>
      </div>

      {/* Content */}
      <div className="p-6 space-y-8 overflow-y-auto">
        
        {/* Presets */}
        <div>
           <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">预设风格</h3>
           <div className="grid grid-cols-2 gap-3">
              {PRESET_BUTTONS.map((btn) => (
                <button
                  key={btn.id}
                  onClick={() => handlePresetClick(btn.id)}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl border transition-all ${
                    activePreset === btn.id 
                      ? `border-transparent ${btn.color} text-white shadow-lg scale-105` 
                      : 'border-slate-700 bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  <btn.icon size={20} className="mb-1" />
                  <span className="text-xs font-bold">{btn.label}</span>
                </button>
              ))}
           </div>
        </div>

        {/* EQ Sliders */}
        <div>
           <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4 flex justify-between">
             <span>均衡器 (EQ)</span>
             <span className="text-indigo-400 text-[10px]">{activePreset === 'Custom' ? '(自定义)' : ''}</span>
           </h3>
           <div className="flex justify-between gap-2 h-40 bg-slate-800/50 rounded-xl p-4 border border-slate-700">
              <EQSlider label="Low" val={eq.low} onChange={(v) => handleEQChange('low', v)} color="accent-rose-500" />
              <EQSlider label="Mid" val={eq.mid} onChange={(v) => handleEQChange('mid', v)} color="accent-emerald-500" />
              <EQSlider label="High" val={eq.high} onChange={(v) => handleEQChange('high', v)} color="accent-sky-500" />
           </div>
        </div>

        {/* Reverb Slider */}
        <div>
           <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">空间感 (Reverb)</h3>
           <div className="bg-slate-800 rounded-xl p-4 border border-slate-700">
             <div className="flex justify-between text-xs text-slate-400 mb-2">
               <span>干音 (Dry)</span>
               <span>湿音 (Wet)</span>
             </div>
             <input 
               type="range" 
               min="0" 
               max="1" 
               step="0.05" 
               value={reverb} 
               onChange={(e) => handleReverbChange(parseFloat(e.target.value))}
               className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
             />
           </div>
        </div>

      </div>
    </div>
  );
};

const EQSlider = ({ label, val, onChange, color }: { label: string, val: number, onChange: (v: number) => void, color: string }) => (
  <div className="flex flex-col items-center h-full w-full">
     <input 
       type="range" 
       min="-12" 
       max="12" 
       step="1" 
       value={val}
       onChange={(e) => onChange(parseFloat(e.target.value))}
       className={`w-2 h-full -rotate-180 writing-vertical-lr appearance-none bg-slate-700 rounded-lg cursor-pointer ${color}`}
       style={{ WebkitAppearance: 'slider-vertical' as any }} 
     />
     <span className="text-[10px] text-slate-400 mt-2 font-mono uppercase">{label}</span>
  </div>
);
