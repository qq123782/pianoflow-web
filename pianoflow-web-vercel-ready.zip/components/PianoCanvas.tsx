
import React, { useEffect, useRef, useState } from 'react';
import { audioService } from '../services/audioService';
import { midiService } from '../services/midiService';
import { SongNote, NoteState, GameStats, ThemeMode } from '../types';

interface PianoCanvasProps {
  isPlaying: boolean;
  isWaitMode: boolean;
  isAutoPlay: boolean;
  songData: SongNote[];
  onStatsUpdate: (stats: GameStats) => void;
  playbackSpeed: number;
  theme: ThemeMode;
}

// Fruit Types helper
type FruitType = 'watermelon' | 'orange' | 'lemon' | 'apple' | 'blueberry';

interface VisualEffect {
  id: number;
  type: 'perfect' | 'good' | 'miss' | 'hit-particle' | 'shockwave' | 'slash' | 'shatter' | 'juice' | 'paint-swirl' | 'sliced-fruit' | 'fairy-dust' | 'bloom-ring';
  x: number; // Screen X (relative offset for moving particles)
  worldX: number; // World X for anchor
  y: number; // Screen Y offset
  startTime: number;
  color: string;
  text?: string;
  // Physics props
  vx?: number; 
  vy?: number; 
  rotation?: number;
  rotationSpeed?: number;
  life?: number; 
  size?: number;
  // Slash specific
  angle?: number;
  // Fruit specific
  fruitType?: FruitType;
  sliceSide?: 'left' | 'right'; // Which half of the fruit
}

// Starry Night Particle Definition
interface StarryParticle {
    x: number;
    y: number;
    vx: number;
    vy: number;
    life: number;
    maxLife: number;
    color: string;
    width: number;
    length: number;
}

// Watermelon Theme Particle
interface WatermelonParticle {
    x: number; 
    y: number;
    vx: number; 
    vy: number;
    rotation: number; 
    rotSpeed: number;
    size: number;
    type: 'seed' | 'pulp' | 'bubble';
    opacity: number;
}

// Dream Theme Particle (Bokeh)
interface DreamParticle {
    x: number;
    y: number;
    vx: number;
    vy: number;
    baseSize: number;
    sizeOscillation: number;
    phase: number;
    color: string;
    opacity: number;
}

const MIN_MIDI = 21; // A0
const MAX_MIDI = 108; // C8
const TOTAL_KEYS = MAX_MIDI - MIN_MIDI + 1;
const KEY_HEIGHT = 220;
const NOTE_SPEED = 400;

const BLOCK_HEIGHT = 40; 
const FOG_HEIGHT_RATIO = 0.25; 

const MIN_SCALE = 0.5;
const MAX_SCALE = 3.0;

const MINIMAP_WIDTH = 240;
const MINIMAP_HEIGHT = 140;
const MINIMAP_LOOKAHEAD = 12; 

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

const KEYBOARD_MAP: { [key: string]: number } = {
  'z': 60, 's': 61, 'x': 62, 'd': 63, 'c': 64, 'v': 65, 'g': 66, 'b': 67, 'h': 68, 'n': 69, 'j': 70, 'm': 71,
  ',': 72, 'l': 73, '.': 74, ';': 75, '/': 76,
  'q': 48, '2': 49, 'w': 50, '3': 51, 'e': 52, '4': 53, 'r': 54, '5': 55, 't': 56, '6': 57, 'y': 58, '7': 59
};

export const PianoCanvas: React.FC<PianoCanvasProps> = ({
  isPlaying,
  isWaitMode,
  isAutoPlay,
  songData,
  onStatsUpdate,
  playbackSpeed,
  theme
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const minimapRef = useRef<HTMLCanvasElement>(null);
  const [canvasSize, setCanvasSize] = useState({ width: 0, height: 0 });
  
  const viewRef = useRef({
    scale: 1.2, 
    offsetX: 0,
    lastPinchDist: 0, 
  });

  const pointersRef = useRef(new Map<number, PointerState>());

  const stateRef = useRef({
    notes: [] as SongNote[],
    songProgress: 0,
    lastFrameTime: 0,
    activeKeys: new Set<number>(), 
    activeAutoKeys: new Map<number, number>(), 
    stats: {
      score: 0,
      streak: 0,
      maxStreak: 0,
      hits: { perfect: 0, good: 0, miss: 0 }
    },
    effects: [] as VisualEffect[],
    effectIdCounter: 0,
    isWaiting: false,
    // Screen Shake State
    shake: 0,
    shakeX: 0,
    shakeY: 0,
    // Starry Night specific
    starryParticles: [] as StarryParticle[],
    // Fruit Theme specific (Watermelon)
    watermelonParticles: [] as WatermelonParticle[],
    // Dream Theme specific
    dreamParticles: [] as DreamParticle[]
  });

  const isBlackKey = (midi: number) => {
    const n = midi % 12;
    return n === 1 || n === 3 || n === 6 || n === 8 || n === 10;
  };

  const getWhiteKeyIndex = (midi: number) => {
    let count = 0;
    for (let i = MIN_MIDI; i < midi; i++) {
      if (!isBlackKey(i)) count++;
    }
    return count;
  };

  const getNoteName = (midi: number) => {
    return NOTE_NAMES[midi % 12];
  };

  const getFruitType = (midi: number): FruitType => {
      // Determine fruit based on midi to keep it consistent per note
      const n = midi % 5;
      switch(n) {
          case 0: return 'watermelon';
          case 1: return 'orange';
          case 2: return 'lemon';
          case 3: return 'apple';
          default: return 'blueberry';
      }
  };

  const getFruitColors = (type: FruitType) => {
      switch(type) {
          case 'watermelon': return { skin: '#166534', flesh: '#ef4444', detail: '#052e16' }; // Green skin, Red flesh
          case 'orange': return { skin: '#f97316', flesh: '#fdba74', detail: '#c2410c' }; 
          case 'lemon': return { skin: '#facc15', flesh: '#fef08a', detail: '#eab308' };
          case 'apple': return { skin: '#dc2626', flesh: '#fef3c7', detail: '#991b1b' };
          case 'blueberry': return { skin: '#4f46e5', flesh: '#818cf8', detail: '#312e81' };
      }
  };

  const totalWhiteKeys = getWhiteKeyIndex(MAX_MIDI + 1);
  
  const getWorldNoteX = (midi: number, screenWidth: number) => {
    const whiteKeyWidth = screenWidth / totalWhiteKeys;
    const whiteIndex = getWhiteKeyIndex(midi);
    
    if (!isBlackKey(midi)) {
      return whiteIndex * whiteKeyWidth;
    } else {
      const blackKeyWidth = whiteKeyWidth * 0.65;
      return (whiteIndex * whiteKeyWidth) - (blackKeyWidth / 2);
    }
  };

  const getWorldNoteWidth = (midi: number, screenWidth: number) => {
    const whiteKeyWidth = screenWidth / totalWhiteKeys;
    return isBlackKey(midi) ? whiteKeyWidth * 0.65 : whiteKeyWidth;
  };

  const toScreenX = (worldX: number) => {
    return (worldX * viewRef.current.scale) + viewRef.current.offsetX;
  };

  const toWorldX = (screenX: number) => {
    return (screenX - viewRef.current.offsetX) / viewRef.current.scale;
  };

  // --- EFFECTS SYSTEM ---

  const spawnHitEffect = (midi: number, isAuto: boolean = false) => {
    const width = canvasSize.width;
    if (width === 0) return;
    
    const worldW = getWorldNoteWidth(midi, width);
    const worldX = getWorldNoteX(midi, width) + (worldW / 2);
    const now = performance.now() / 1000; 
    const state = stateRef.current;
    const keyTopY = canvasSize.height - KEY_HEIGHT;

    if (theme === 'classic') {
        // Classic Effects
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'shockwave',
            x: 0, worldX: worldX, y: keyTopY,
            startTime: now,
            color: isAuto ? '#ec4899' : '#facc15',
            life: 0.4, size: 10
        });

        const particleCount = 8; 
        const isBlack = isBlackKey(midi);
        const palette = isAuto 
            ? ['#f472b6', '#fb7185', '#ffffff'] 
            : (isBlack ? ['#2dd4bf', '#ccfbf1', '#ffffff'] : ['#3b82f6', '#93c5fd', '#ffffff']);
        
        for (let i = 0; i < particleCount; i++) {
            const angle = (Math.random() * Math.PI) + Math.PI; 
            const speed = Math.random() * 200 + 100; 
            state.effects.push({
                id: state.effectIdCounter++,
                type: 'hit-particle',
                x: 0, worldX: worldX, y: 0, startTime: now,
                color: palette[Math.floor(Math.random() * palette.length)],
                vx: Math.cos(angle * 2) * speed * (Math.random() - 0.5) * 4, 
                vy: -Math.abs(Math.sin(angle)) * speed, 
                life: Math.random() * 0.4 + 0.2, 
                size: Math.random() * 4 + 2
            });
        }
    } else if (theme === 'neon') {
        // NEON EFFECTS
        const slashAngle = (Math.random() * Math.PI / 2) - (Math.PI / 4); 
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'slash',
            x: 0, worldX: worldX, y: keyTopY - 20,
            startTime: now,
            color: '#ffffff',
            life: 0.15, size: 100 + Math.random() * 50, angle: slashAngle
        });

        const shardCount = 6;
        const isBlack = isBlackKey(midi);
        const palette = isAuto ? ['#ff00ff', '#ff69b4', '#ffffff'] : (isBlack ? ['#00f3ff', '#ccfbf1', '#ffffff'] : ['#bc13fe', '#d8b4fe', '#ffffff']);

        for (let i = 0; i < shardCount; i++) {
             const angle = (Math.random() * Math.PI * 2); 
             const speed = Math.random() * 400 + 200; 
             state.effects.push({
                id: state.effectIdCounter++,
                type: 'shatter',
                x: 0, worldX: worldX, y: -20, 
                startTime: now,
                color: palette[Math.floor(Math.random() * palette.length)],
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 200, 
                rotation: Math.random() * Math.PI,
                rotationSpeed: (Math.random() - 0.5) * 10,
                life: 0.6, size: Math.random() * 10 + 5
             });
        }
        state.shake = 8; 
    } else if (theme === 'fruit') {
        // JUICY WATERMELON EFFECTS
        const fruitType = getFruitType(midi);
        const colors = getFruitColors(fruitType);
        const slashAngle = (Math.random() * Math.PI / 2) - (Math.PI / 4); 

        // 1. The Blade Slash
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'slash',
            x: 0, worldX: worldX, y: keyTopY - 30,
            startTime: now,
            color: '#fef08a', 
            life: 0.2, size: 180, angle: slashAngle
        });
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'slash',
            x: -2, worldX: worldX, y: keyTopY - 32, 
            startTime: now + 0.01,
            color: '#ffffff', 
            life: 0.2, size: 180, angle: slashAngle
        });
        
        // 2. Sliced Fruit Halves
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'sliced-fruit',
            fruitType: fruitType,
            sliceSide: 'left',
            x: 0, worldX: worldX, y: -30,
            startTime: now,
            color: colors.skin,
            vx: -150 - Math.random() * 100,
            vy: -300 - Math.random() * 100,
            rotation: slashAngle,
            rotationSpeed: -5 - Math.random() * 5,
            life: 0.8, size: 25
        });
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'sliced-fruit',
            fruitType: fruitType,
            sliceSide: 'right',
            x: 0, worldX: worldX, y: -30,
            startTime: now,
            color: colors.skin,
            vx: 150 + Math.random() * 100, 
            vy: -300 - Math.random() * 100,
            rotation: slashAngle,
            rotationSpeed: 5 + Math.random() * 5,
            life: 0.8, size: 25
        });

        // 3. Juice Splatter
        for(let i=0; i<8; i++) {
            const angle = slashAngle + (Math.random() - 0.5) * 2; 
            const speed = Math.random() * 400 + 200;
            const juiceColor = fruitType === 'watermelon' ? '#fecdd3' : colors.flesh;
            
            state.effects.push({
                id: state.effectIdCounter++,
                type: 'juice',
                x: 0, worldX: worldX, y: -30,
                startTime: now,
                color: juiceColor,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                life: 0.4 + Math.random() * 0.2,
                size: Math.random() * 6 + 4
            });
        }
        state.shake = 4;
    } else if (theme === 'starry') {
        // STARRY NIGHT EFFECTS
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'paint-swirl',
            x: 0, worldX: worldX, y: keyTopY,
            startTime: now,
            color: '#fde047', 
            life: 1.0,
            size: 50
        });
        
        for(let i=0; i<5; i++) {
             state.effects.push({
                id: state.effectIdCounter++,
                type: 'hit-particle', 
                x: 0, worldX: worldX, y: 0, startTime: now,
                color: '#facc15',
                vx: (Math.random() - 0.5) * 80,
                vy: -Math.random() * 150 - 50,
                life: 1.5, size: Math.random() * 4 + 2
            });
        }
    } else if (theme === 'dream') {
        // DREAM / FANTASY EFFECTS
        // Soft expanding light ring
        state.effects.push({
            id: state.effectIdCounter++,
            type: 'bloom-ring',
            x: 0, worldX: worldX, y: keyTopY - 10,
            startTime: now,
            color: '#fff',
            life: 0.8, 
            size: 30
        });

        // Sparkles / Fairy Dust
        const count = 12;
        const colors = ['#fff', '#fdf4ff', '#f0abfc', '#fcd34d']; // White, Pale Pink, Fuchsia, Gold
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = Math.random() * 100 + 20;
            state.effects.push({
                id: state.effectIdCounter++,
                type: 'fairy-dust',
                x: 0, worldX: worldX, y: -10,
                startTime: now,
                color: colors[Math.floor(Math.random() * colors.length)],
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed - 50, // Float up slightly
                life: Math.random() * 1.0 + 0.5,
                size: Math.random() * 3 + 1
            });
        }
    }
  };

  // --- INITIALIZATION ---

  useEffect(() => {
    const notesCopy = JSON.parse(JSON.stringify(songData));
    notesCopy.sort((a: SongNote, b: SongNote) => a.startTime - b.startTime);
    
    stateRef.current.notes = notesCopy;
    stateRef.current.songProgress = 0;
    stateRef.current.stats = { score: 0, streak: 0, maxStreak: 0, hits: { perfect: 0, good: 0, miss: 0 } };
    stateRef.current.activeKeys.clear();
    stateRef.current.activeAutoKeys.clear();
    stateRef.current.effects = [];
    stateRef.current.isWaiting = false;
    
    onStatsUpdate(stateRef.current.stats);
  }, [songData]);

  // --- HIT LOGIC ---

  const triggerNoteOn = (midi: number, isAuto: boolean = false) => {
    audioService.resumeContext();
    audioService.init(); 

    const state = stateRef.current;
    
    if (!state.activeKeys.has(midi)) {
      state.activeKeys.add(midi);
      audioService.startNote(midi);
      
      if (isPlaying) {
        if (isAuto) {
           checkAutoHit(midi);
        } else {
           if (isWaitMode) {
              checkWaitModeHit(midi);
           } else {
              checkStandardHit(midi);
           }
        }
      }
    }
  };

  const triggerNoteOff = (midi: number) => {
    const state = stateRef.current;
    if (state.activeKeys.has(midi)) {
      state.activeKeys.delete(midi);
      audioService.stopNote(midi);
    }
  };

  const checkAutoHit = (midi: number) => {
      const state = stateRef.current;
      const hitNote = state.notes.find(n => 
          n.state === NoteState.Waiting && 
          n.midi === midi &&
          n.startTime <= state.songProgress + 0.1 
      );

      if (hitNote) {
          hitNote.state = NoteState.Hit;
          state.stats.hits.perfect++;
          state.stats.score += 100; 
          state.stats.streak++;
          if (state.stats.streak > state.stats.maxStreak) state.stats.maxStreak = state.stats.streak;
          
          spawnHitEffect(midi, true);
          onStatsUpdate({ ...state.stats });
          state.activeAutoKeys.set(midi, state.songProgress + hitNote.duration);
      }
  };

  const checkWaitModeHit = (inputMidi: number) => {
    try {
      const state = stateRef.current;
      const nextWaitingNote = state.notes.find(n => n.state === NoteState.Waiting);
      if (!nextWaitingNote) return; 
      if (nextWaitingNote.startTime - state.songProgress > 1.5) return;

      const targetTime = nextWaitingNote.startTime;
      const hitNote = state.notes.find(n => 
        n.state === NoteState.Waiting && 
        n.midi === inputMidi &&
        Math.abs(n.startTime - targetTime) < 0.2 
      );

      if (hitNote) {
        hitNote.state = NoteState.Hit;
        state.stats.hits.perfect++; 
        state.stats.score += 100;
        state.stats.streak++;
        spawnHitEffect(inputMidi);
        onStatsUpdate({ ...state.stats });
      }
    } catch (e) {
      console.error("Error in Wait Mode logic:", e);
    }
  };

  const checkStandardHit = (midiNote: number) => {
    const state = stateRef.current;
    const currentProgress = state.songProgress;
    
    const note = state.notes.find(n => 
      n.midi === midiNote && 
      n.state === NoteState.Waiting &&
      Math.abs(n.startTime - currentProgress) < 0.25 
    );

    if (note) {
      note.state = NoteState.Hit;
      state.stats.hits.perfect++;
      state.stats.score += 100 + (state.stats.streak * 10);
      state.stats.streak++;
      if (state.stats.streak > state.stats.maxStreak) state.stats.maxStreak = state.stats.streak;
      spawnHitEffect(midiNote);
      onStatsUpdate({ ...state.stats });
    }
  };

  // --- INPUT HANDLING ---

  useEffect(() => {
    const handleMidi = (command: number, note: number, velocity: number) => {
      const isNoteOn = (command & 0xf0) === 0x90 && velocity > 0;
      const isNoteOff = (command & 0xf0) === 0x80 || ((command & 0xf0) === 0x90 && velocity === 0);
      if (isNoteOn) triggerNoteOn(note);
      if (isNoteOff) triggerNoteOff(note);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.repeat) return;
      const key = e.key.toLowerCase();
      if (KEYBOARD_MAP[key]) {
        triggerNoteOn(KEYBOARD_MAP[key]);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      if (KEYBOARD_MAP[key]) {
        triggerNoteOff(KEYBOARD_MAP[key]);
      }
    };

    midiService.addListener(handleMidi);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      midiService.removeListener(handleMidi);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [isPlaying, isWaitMode, theme]); 

  interface PointerState {
    id: number;
    startX: number;
    startY: number;
    currentX: number;
    currentY: number;
    midi?: number; 
    isDrag: boolean;
  }

  // --- TOUCH LOGIC ---

  const getMidiFromScreenPoint = (screenX: number, screenY: number, width: number, height: number) => {
    const keyTopY = height - KEY_HEIGHT;
    // 1. DIRECT NOTE HIT
    if (isPlaying) {
       const state = stateRef.current;
       for (const note of state.notes) {
         if (note.state !== NoteState.Waiting) continue;
         const timeToHit = note.startTime - state.songProgress;
         const noteBottomY = keyTopY - (timeToHit * NOTE_SPEED);
         const noteTopY = noteBottomY - BLOCK_HEIGHT;
         if (noteTopY > height || noteBottomY < 0) continue;

         const worldX = getWorldNoteX(note.midi, width);
         const worldW = getWorldNoteWidth(note.midi, width);
         const noteScreenX = toScreenX(worldX);
         const noteScreenW = worldW * viewRef.current.scale;

         const pad = 30;
         if (screenX >= noteScreenX - pad && screenX <= noteScreenX + noteScreenW + pad && screenY >= noteTopY - pad && screenY <= noteBottomY + pad) {
           return note.midi;
         }
       }
    }
    // 2. KEYBOARD HIT
    if (screenY > keyTopY) {
       const worldX = toWorldX(screenX);
       const blackKeyHeight = KEY_HEIGHT * 0.65;
       if (screenY < keyTopY + blackKeyHeight) {
         for (let m = MIN_MIDI; m <= MAX_MIDI; m++) {
           if (isBlackKey(m)) {
             const kx = getWorldNoteX(m, width);
             const kw = getWorldNoteWidth(m, width);
             if (worldX >= kx && worldX <= kx + kw) return m;
           }
         }
       }
       const whiteKeyWidth = width / totalWhiteKeys;
       const whiteIndex = Math.floor(worldX / whiteKeyWidth);
       let currentWhite = 0;
       for (let m = MIN_MIDI; m <= MAX_MIDI; m++) {
         if (!isBlackKey(m)) {
           if (currentWhite === whiteIndex) return m;
           currentWhite++;
         }
       }
    }
    return -1;
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    audioService.resumeContext();
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const midi = getMidiFromScreenPoint(x, y, canvasSize.width, canvasSize.height);

    const pointerData: PointerState = {
      id: e.pointerId,
      startX: e.clientX, startY: e.clientY, currentX: e.clientX, currentY: e.clientY,
      midi: midi !== -1 ? midi : undefined,
      isDrag: midi === -1
    };
    pointersRef.current.set(e.pointerId, pointerData);
    if (midi !== -1) triggerNoteOn(midi);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    e.preventDefault(); 
    const ptr = pointersRef.current.get(e.pointerId);
    if (!ptr) return;

    const prevX = ptr.currentX;
    ptr.currentX = e.clientX;
    ptr.currentY = e.clientY;
    pointersRef.current.set(e.pointerId, ptr);

    if (pointersRef.current.size === 2) {
      const ptrs = Array.from(pointersRef.current.values()) as PointerState[];
      const p1 = ptrs[0];
      const p2 = ptrs[1];
      const dist = Math.hypot(p2.currentX - p1.currentX, p2.currentY - p1.currentY);
      if (viewRef.current.lastPinchDist <= 0) {
        viewRef.current.lastPinchDist = dist;
        return;
      }
      const scaleFactor = dist / viewRef.current.lastPinchDist;
      viewRef.current.lastPinchDist = dist;
      const oldScale = viewRef.current.scale;
      let newScale = oldScale * scaleFactor;
      newScale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, newScale));
      const rect = canvasRef.current?.getBoundingClientRect();
      const centerX = (p1.currentX + p2.currentX) / 2;
      const relativeCenterX = centerX - (rect?.left || 0);
      const worldX = (relativeCenterX - viewRef.current.offsetX) / oldScale;
      viewRef.current.scale = newScale;
      viewRef.current.offsetX = relativeCenterX - (worldX * newScale);
      return;
    } else {
      viewRef.current.lastPinchDist = 0;
    }
    if (pointersRef.current.size === 1 && ptr.isDrag) {
       const deltaX = ptr.currentX - prevX; 
       viewRef.current.offsetX += deltaX;
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    const ptr = pointersRef.current.get(e.pointerId);
    if (ptr && ptr.midi !== undefined) {
      triggerNoteOff(ptr.midi);
    }
    pointersRef.current.delete(e.pointerId);
    if (pointersRef.current.size < 2) viewRef.current.lastPinchDist = 0;
  };

  // --- RENDER LOOP ---

  useEffect(() => {
    const canvas = canvasRef.current;
    const minimapCanvas = minimapRef.current;
    if (!canvas || !minimapCanvas) return;
    
    const ctx = canvas.getContext('2d', { alpha: false });
    const miniCtx = minimapCanvas.getContext('2d', { alpha: true });
    if (!ctx || !miniCtx) return;

    let animationFrameId: number;

    const render = (time: number) => {
      const state = stateRef.current;
      if (state.lastFrameTime === 0) state.lastFrameTime = time;
      const dt = (time - state.lastFrameTime) / 1000;
      state.lastFrameTime = time;

      const width = canvasSize.width;
      const height = canvasSize.height;

      if (width === 0) {
        animationFrameId = requestAnimationFrame(render);
        return;
      }

      // Physics Update (Shake)
      if (state.shake > 0) {
          state.shakeX = (Math.random() - 0.5) * state.shake;
          state.shakeY = (Math.random() - 0.5) * state.shake;
          state.shake *= 0.9; // Decay
          if (state.shake < 0.5) state.shake = 0;
      } else {
          state.shakeX = 0;
          state.shakeY = 0;
      }

      // Game Logic
      let shouldProgress = isPlaying;
      if (isPlaying && isWaitMode && !isAutoPlay) {
         const nextNote = state.notes.find(n => n.state === NoteState.Waiting);
         if (nextNote) {
             const timeToLine = nextNote.startTime - state.songProgress;
             if (timeToLine <= 0.02) {
                 shouldProgress = false;
                 state.isWaiting = true;
                 state.songProgress = nextNote.startTime;
             } else {
                 state.isWaiting = false;
             }
         } else {
             state.isWaiting = false;
         }
      } else {
          state.isWaiting = false;
      }

      if (shouldProgress) {
        state.songProgress += dt * playbackSpeed;
      }

      if (isPlaying && isAutoPlay) {
          state.notes.forEach(note => {
              if (note.state === NoteState.Waiting && state.songProgress >= note.startTime) {
                  triggerNoteOn(note.midi, true);
              }
          });
          state.activeAutoKeys.forEach((endTime, midi) => {
              if (state.songProgress >= endTime) {
                  triggerNoteOff(midi);
                  state.activeAutoKeys.delete(midi);
              }
          });
      }

      // --- DRAWING PHASE ---
      ctx.save();
      // Apply Screen Shake
      if (state.shake > 0) {
          ctx.translate(state.shakeX, state.shakeY);
      }

      const keyTopY = height - KEY_HEIGHT;
      const currentScale = viewRef.current.scale;

      // BACKGROUND
      if (theme === 'classic') {
          drawClassicBackground(ctx, width, height);
      } else if (theme === 'neon') {
          drawNeonBackground(ctx, width, height, time);
      } else if (theme === 'fruit') {
          drawFruitBackground(ctx, width, height, dt);
      } else if (theme === 'starry') {
          drawStarryBackground(ctx, width, height, time, dt); 
      } else if (theme === 'dream') {
          drawDreamBackground(ctx, width, height, time, dt);
      }

      // GRID
      if (theme === 'classic' || theme === 'starry' || theme === 'dream') {
          ctx.strokeStyle = theme === 'classic' 
              ? 'rgba(255,255,255,0.05)' 
              : (theme === 'dream' ? 'rgba(255,255,255,0.1)' : 'rgba(255,255,200,0.05)');
          ctx.lineWidth = 1;
          ctx.beginPath();
          for (let i = 0; i <= totalWhiteKeys; i++) {
            const worldX = i * (width / totalWhiteKeys);
            const screenX = toScreenX(worldX);
            if (screenX >= -50 && screenX <= width + 50) {
                ctx.moveTo(screenX, 0);
                ctx.lineTo(screenX, keyTopY);
            }
          }
          ctx.stroke();
      }

      // Active Beams
      ctx.globalCompositeOperation = 'lighter';
      state.activeKeys.forEach(midi => {
         const worldX = getWorldNoteX(midi, width);
         const worldW = getWorldNoteWidth(midi, width);
         const screenX = toScreenX(worldX);
         const screenW = worldW * currentScale;
         const isAutoHeld = state.activeAutoKeys.has(midi);
         
         if (screenX + screenW > 0 && screenX < width) {
            const beamGrad = ctx.createLinearGradient(0, keyTopY - 300, 0, keyTopY);
            let color = '59, 130, 246'; // Default Blue
            if (theme === 'neon') {
                color = isAutoHeld ? '255, 0, 255' : (isBlackKey(midi) ? '0, 243, 255' : '188, 19, 254');
            } else if (theme === 'fruit') {
                color = isAutoHeld ? '253, 186, 116' : '254, 205, 211'; 
            } else if (theme === 'starry') {
                color = '253, 224, 71'; 
            } else if (theme === 'dream') {
                color = isAutoHeld ? '253, 224, 71' : '244, 114, 182'; // Gold or Pink
            } else {
                color = isAutoHeld ? '236, 72, 153' : (isBlackKey(midi) ? '45, 212, 191' : '59, 130, 246');
            }
            
            if (theme === 'fruit') {
                beamGrad.addColorStop(0, `rgba(${color}, 0)`);
                beamGrad.addColorStop(1, `rgba(${color}, 0.5)`);
            } else if (theme === 'dream') {
                beamGrad.addColorStop(0, `rgba(${color}, 0)`);
                beamGrad.addColorStop(1, `rgba(${color}, 0.3)`);
            } else {
                beamGrad.addColorStop(0, `rgba(${color}, 0)`);
                beamGrad.addColorStop(1, `rgba(${color}, 0.4)`);
            }
            
            ctx.fillStyle = beamGrad;
            ctx.fillRect(screenX, 0, screenW, keyTopY);
         }
      });
      ctx.globalCompositeOperation = 'source-over';

      // Judge Line
      if (theme === 'neon') {
        ctx.strokeStyle = '#ff00ff';
        ctx.lineWidth = 2;
        ctx.shadowColor = '#ff00ff';
        ctx.shadowBlur = 20;
        ctx.beginPath(); ctx.moveTo(0, keyTopY); ctx.lineTo(width, keyTopY); ctx.stroke();
        ctx.shadowBlur = 0;
      } else if (theme === 'fruit') {
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillRect(0, keyTopY - 2, width, 4);
      } else if (theme === 'starry' || theme === 'dream') {
          // No sharp line
      } else {
        if (state.isWaiting) {
            const pulse = (Math.sin(time / 150) + 1) * 0.5;
            ctx.strokeStyle = `rgba(251, 191, 36, ${0.6 + pulse * 0.4})`; 
            ctx.shadowColor = '#f59e0b';
            ctx.shadowBlur = 20 + (pulse * 10);
            ctx.lineWidth = 4;
            ctx.beginPath(); ctx.moveTo(0, keyTopY); ctx.lineTo(width, keyTopY); ctx.stroke();
            ctx.shadowBlur = 0;
        } else {
            ctx.strokeStyle = isAutoPlay ? '#ec4899' : '#38bdf8';
            ctx.shadowColor = isAutoPlay ? '#ec4899' : '#38bdf8';
            ctx.lineWidth = 2;
            ctx.shadowBlur = 15;
            ctx.beginPath(); ctx.moveTo(0, keyTopY); ctx.lineTo(width, keyTopY); ctx.stroke();
            ctx.shadowBlur = 0;
        }
      }

      // NOTES
      const visibleTopY = height * FOG_HEIGHT_RATIO;
      state.notes.forEach(note => {
        if (note.state === NoteState.Hit) return;
        const timeToHit = note.startTime - state.songProgress;
        const noteBottomY = keyTopY - (timeToHit * NOTE_SPEED);
        const blockH = BLOCK_HEIGHT; 
        const noteTopY = noteBottomY - blockH;
        if (noteBottomY < visibleTopY - 50 || noteTopY > height + 50) return;

        const worldX = getWorldNoteX(note.midi, width);
        const worldW = getWorldNoteWidth(note.midi, width);
        const screenX = toScreenX(worldX);
        const screenW = worldW * currentScale;
        if (screenX + screenW < 0 || screenX > width) return;
        const isBlack = isBlackKey(note.midi);
        const isBlocking = state.isWaiting && Math.abs(timeToHit) <= 0.05;
        
        const visualW = screenW * 0.9; 
        const visualX = screenX + (screenW - visualW) / 2;

        if (theme === 'neon') {
            drawNeonNote(ctx, note, visualX, noteTopY, visualW, blockH, isBlack, isBlocking, isAutoPlay);
        } else if (theme === 'fruit') {
            drawFruitNote(ctx, note, visualX, noteTopY, visualW, blockH, isBlack, isBlocking, isAutoPlay);
        } else if (theme === 'starry') {
            drawStarryNote(ctx, note, visualX, noteTopY, visualW, blockH, isBlack, isBlocking, isAutoPlay);
        } else if (theme === 'dream') {
            drawDreamNote(ctx, note, visualX, noteTopY, visualW, blockH, isBlack, isBlocking, isAutoPlay);
        } else {
            drawClassicNote(ctx, note, visualX, noteTopY, visualW, blockH, isBlack, isBlocking, isAutoPlay);
        }
        
        // Labels
        if (currentScale > 1.2 || isBlocking) {
             ctx.fillStyle = theme === 'neon' || theme === 'starry' || theme === 'dream' ? '#fff' : (isBlocking ? '#000' : (theme === 'fruit' ? '#fff' : '#1e293b'));
             ctx.font = "bold 12px sans-serif";
             ctx.textAlign = 'center';
             ctx.textBaseline = 'middle';
             ctx.fillText(getNoteName(note.midi), visualX + visualW/2, noteTopY + blockH/2);
        }
      });

      // Fog
      if (theme === 'classic') {
          const fogGrad = ctx.createLinearGradient(0, 0, 0, height * FOG_HEIGHT_RATIO + 20);
          fogGrad.addColorStop(0, '#020617');
          fogGrad.addColorStop(0.4, '#020617');
          fogGrad.addColorStop(1, 'rgba(2, 6, 23, 0)');
          ctx.fillStyle = fogGrad;
          ctx.fillRect(0, 0, width, height);
      }

      // Keys
      drawKeys(ctx, width, height, state, keyTopY, currentScale, theme);

      // Effects
      drawEffects(ctx, state, keyTopY, dt);

      ctx.restore(); // Pop Shake

      // Prompts
      if (state.isWaiting) {
          ctx.save();
          ctx.fillStyle = theme === 'fruit' ? '#fef3c7' : '#facc15';
          ctx.font = "900 32px sans-serif"; 
          ctx.textAlign = 'center';
          if (theme === 'fruit') {
             ctx.shadowColor = 'rgba(0,0,0,0.3)';
             ctx.shadowBlur = 5;
          } else {
             ctx.shadowColor = 'rgba(0,0,0,0.8)';
             ctx.shadowBlur = 10;
             ctx.strokeStyle = 'black';
             ctx.lineWidth = 3;
             ctx.strokeText("等待按键输入", width/2, keyTopY - 50);
          }
          const cx = width / 2;
          const cy = keyTopY - 50;
          ctx.fillText("等待按键输入", cx, cy);
          ctx.restore();
      }
      
      if (isPlaying && isAutoPlay && !state.isWaiting) {
          ctx.save();
          ctx.font = "900 24px sans-serif"; 
          ctx.textAlign = 'center';
          const cx = width / 2;
          const cy = keyTopY - 80;
          const pulse = (Math.sin(time / 200) + 1) * 0.5;
          ctx.fillStyle = `rgba(236, 72, 153, ${0.5 + pulse * 0.5})`;
          ctx.shadowColor = '#ec4899';
          ctx.shadowBlur = 10;
          ctx.fillText("AI 托管演示中...", cx, cy);
          ctx.restore();
      }

      // --- MINIMAP ---
      drawMinimap(miniCtx, width, state, isAutoPlay, isWaitMode, theme);

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animationFrameId);
  }, [isPlaying, isWaitMode, isAutoPlay, canvasSize, theme]);


  // --- DRAWING HELPERS ---

  const drawClassicBackground = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    const bgGrad = ctx.createRadialGradient(w/2, h*0.8, h*0.1, w/2, h*0.5, h);
    bgGrad.addColorStop(0, '#0f172a'); 
    bgGrad.addColorStop(1, '#020617'); 
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, w, h);
  };

  const drawNeonBackground = (ctx: CanvasRenderingContext2D, w: number, h: number, time: number) => {
     const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
     bgGrad.addColorStop(0, '#0b001a');
     bgGrad.addColorStop(1, '#1a002e');
     ctx.fillStyle = bgGrad;
     ctx.fillRect(0, 0, w, h);

     ctx.strokeStyle = 'rgba(188, 19, 254, 0.3)'; 
     ctx.lineWidth = 2;
     ctx.beginPath();
     
     const speed = 0.2; 
     const offset = (time * speed) % 1;
     const horizonY = h * 0.2;
     
     const vanishingPointX = w / 2;
     const vanishingPointY = horizonY;
     
     for(let i=-10; i<=20; i++) {
         const x = (i * w / 10) + (w/2);
         ctx.moveTo(vanishingPointX + (x - vanishingPointX) * 0.1, vanishingPointY);
         ctx.lineTo(x, h);
     }

     for(let i=0; i<10; i++) {
         const progress = (i + offset) / 10;
         const y = horizonY + Math.pow(progress, 3) * (h - horizonY);
         ctx.moveTo(0, y);
         ctx.lineTo(w, y);
     }
     ctx.stroke();

     const sunGrad = ctx.createLinearGradient(w/2, horizonY - 100, w/2, horizonY + 50);
     sunGrad.addColorStop(0, '#ff00ff');
     sunGrad.addColorStop(1, 'rgba(255,0,255,0)');
     ctx.fillStyle = sunGrad;
     ctx.globalCompositeOperation = 'screen';
     ctx.beginPath();
     ctx.arc(w/2, horizonY, 150, Math.PI, 0);
     ctx.fill();
     ctx.globalCompositeOperation = 'source-over';
  };

  const drawFruitBackground = (ctx: CanvasRenderingContext2D, w: number, h: number, dt: number) => {
      const state = stateRef.current;
      const bgGrad = ctx.createRadialGradient(w/2, h/2, w*0.1, w/2, h/2, w*0.8);
      bgGrad.addColorStop(0, '#fecdd3'); 
      bgGrad.addColorStop(0.5, '#fb7185'); 
      bgGrad.addColorStop(1, '#e11d48'); 
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      if (state.watermelonParticles.length < 30) {
          state.watermelonParticles.push({
              x: Math.random() * w,
              y: Math.random() * h,
              vx: (Math.random() - 0.5) * 20,
              vy: -10 - Math.random() * 30, 
              rotation: Math.random() * Math.PI * 2,
              rotSpeed: (Math.random() - 0.5),
              size: Math.random() * 10 + 5,
              type: Math.random() > 0.6 ? 'seed' : (Math.random() > 0.5 ? 'bubble' : 'pulp'),
              opacity: Math.random() * 0.8 + 0.2
          });
      }

      state.watermelonParticles.forEach(p => {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.rotation += p.rotSpeed * dt;
          if (p.y < -50) p.y = h + 50;
          if (p.x < -50) p.x = w + 50;
          if (p.x > w + 50) p.x = -50;

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          
          if (p.type === 'seed') {
              ctx.fillStyle = 'rgba(20, 20, 20, 0.8)';
              ctx.beginPath();
              ctx.ellipse(0, 0, p.size/2, p.size, 0, 0, Math.PI*2);
              ctx.fill();
              ctx.fillStyle = 'rgba(255,255,255,0.3)';
              ctx.beginPath();
              ctx.ellipse(-p.size/6, -p.size/4, p.size/6, p.size/6, 0, 0, Math.PI*2);
              ctx.fill();
          } else if (p.type === 'pulp') {
              ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity * 0.3})`;
              ctx.beginPath();
              ctx.arc(0, 0, p.size * 2, 0, Math.PI*2);
              ctx.fill();
          } else {
              ctx.fillStyle = `rgba(255, 200, 200, ${p.opacity * 0.5})`;
              ctx.beginPath();
              ctx.arc(0, 0, p.size, 0, Math.PI*2);
              ctx.fill();
          }
          ctx.restore();
      });
  };

  // --- DREAM (BOKEH) LOGIC ---
  const drawDreamBackground = (ctx: CanvasRenderingContext2D, w: number, h: number, time: number, dt: number) => {
      const state = stateRef.current;

      // 1. Warm/Pink/Peach Gradient (Fantasy Sunset)
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#fbc2eb'); // Lavender Pink
      bgGrad.addColorStop(0.5, '#ff9a9e'); // Warm Pink/Peach
      bgGrad.addColorStop(1, '#a18cd1'); // Soft Purple
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      // 2. Bokeh Particles
      if (state.dreamParticles.length < 50) {
          state.dreamParticles.push({
              x: Math.random() * w,
              y: h + Math.random() * 100,
              vx: (Math.random() - 0.5) * 10,
              vy: -10 - Math.random() * 20, // Drift up slowly
              baseSize: Math.random() * 30 + 10,
              sizeOscillation: Math.random() * 10,
              phase: Math.random() * Math.PI * 2,
              color: Math.random() > 0.5 ? '#ffffff' : (Math.random() > 0.5 ? '#fef9c3' : '#fce7f3'), // White, Gold, or Light Pink
              opacity: Math.random() * 0.3 + 0.1
          });
      }

      state.dreamParticles.forEach(p => {
          p.y += p.vy * dt;
          p.x += p.vx * dt;
          if (p.y < -50) {
              p.y = h + 50;
              p.x = Math.random() * w;
          }

          const pulsingSize = p.baseSize + Math.sin(time * 0.002 + p.phase) * p.sizeOscillation;
          
          ctx.globalCompositeOperation = 'screen'; // Additive blending for light
          ctx.fillStyle = p.color;
          ctx.globalAlpha = p.opacity;
          
          ctx.beginPath();
          ctx.arc(p.x, p.y, Math.max(0, pulsingSize), 0, Math.PI * 2);
          ctx.fill();
      });
      
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
  };

  // --- STARRY NIGHT LOGIC ---

  const getStarryFlowVector = (x: number, y: number, width: number, height: number, time: number) => {
      const nx = x / width;
      const ny = y / height;
      const cx = width * 0.5;
      const cy = height * 0.4;
      const dx = x - cx;
      const dy = y - cy;
      const dist = Math.sqrt(dx*dx + dy*dy);
      let vx_spiral = -dy;
      let vy_spiral = dx;
      vx_spiral -= dx * 0.5;
      vy_spiral -= dy * 0.5;
      const spiralStrength = Math.max(0, 1 - dist / (width * 0.4));
      const vx_wind = Math.cos(ny * 10 + time * 0.5) * 100;
      const vy_wind = Math.sin(nx * 10 + time * 0.5) * 50;
      return {
          vx: vx_wind * (1 - spiralStrength) + vx_spiral * spiralStrength * 2,
          vy: vy_wind * (1 - spiralStrength) + vy_spiral * spiralStrength * 2
      };
  };

  const drawStarryBackground = (ctx: CanvasRenderingContext2D, w: number, h: number, time: number, dt: number) => {
      const state = stateRef.current;
      const bgGrad = ctx.createLinearGradient(0, 0, 0, h);
      bgGrad.addColorStop(0, '#0b1026'); 
      bgGrad.addColorStop(0.5, '#172554'); 
      bgGrad.addColorStop(1, '#1e3a8a'); 
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, w, h);

      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.moveTo(0, h);
      for(let x=0; x<=w; x+=10) {
          const y = h * 0.8 + Math.sin(x * 0.005) * 50 + Math.cos(x * 0.02) * 20;
          ctx.lineTo(x, y);
      }
      ctx.lineTo(w, h);
      ctx.fill();

      drawCypressTree(ctx, h);

      if (state.starryParticles.length < 400) {
          for(let i=0; i<10; i++) {
              state.starryParticles.push({
                  x: Math.random() * w,
                  y: Math.random() * h * 0.8, 
                  vx: 0, vy: 0,
                  life: Math.random() * 2 + 1,
                  maxLife: 3,
                  color: Math.random() > 0.7 ? '#fde047' : (Math.random() > 0.5 ? '#93c5fd' : '#1d4ed8'), 
                  width: Math.random() * 3 + 1,
                  length: Math.random() * 15 + 5
              });
          }
      }

      ctx.lineCap = 'round';
      for (let i = state.starryParticles.length - 1; i >= 0; i--) {
          const p = state.starryParticles[i];
          p.life -= dt;
          if (p.life <= 0) {
              state.starryParticles.splice(i, 1);
              continue;
          }
          const vec = getStarryFlowVector(p.x, p.y, w, h, time * 0.001);
          p.vx += (vec.vx - p.vx) * 5 * dt;
          p.vy += (vec.vy - p.vy) * 5 * dt;
          p.x += p.vx * 0.1 * dt;
          p.y += p.vy * 0.1 * dt;
          if (p.x < 0) p.x += w;
          if (p.x > w) p.x -= w;
          if (p.y < 0) p.y += h;
          if (p.y > h) p.y -= h;

          const angle = Math.atan2(p.vy, p.vx);
          ctx.strokeStyle = p.color;
          ctx.lineWidth = p.width;
          ctx.globalAlpha = Math.min(1, p.life / 0.5); 
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(p.x + Math.cos(angle) * p.length, p.y + Math.sin(angle) * p.length);
          ctx.stroke();
      }
      ctx.globalAlpha = 1;

      const moonX = w * 0.85;
      const moonY = h * 0.15;
      const moonGlow = ctx.createRadialGradient(moonX, moonY, 10, moonX, moonY, 80);
      moonGlow.addColorStop(0, 'rgba(253, 224, 71, 0.8)');
      moonGlow.addColorStop(1, 'rgba(253, 224, 71, 0)');
      ctx.fillStyle = moonGlow;
      ctx.beginPath(); ctx.arc(moonX, moonY, 80, 0, Math.PI*2); ctx.fill();
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(moonX, moonY, 30, 0, Math.PI*2);
      ctx.fill();
      ctx.fillStyle = '#eab308'; 
      ctx.beginPath(); ctx.arc(moonX - 5, moonY + 5, 25, 0, Math.PI*2); ctx.fill(); 

      const starPositions = [
          {x: 0.2, y: 0.15}, {x: 0.35, y: 0.1}, {x: 0.5, y: 0.2}, 
          {x: 0.6, y: 0.1}, {x: 0.1, y: 0.3}, {x: 0.75, y: 0.3}
      ];

      starPositions.forEach((pos, idx) => {
          const sx = pos.x * w;
          const sy = pos.y * h;
          const pulse = Math.sin(time * 2 + idx) * 0.2 + 1;
          const starGrad = ctx.createRadialGradient(sx, sy, 2, sx, sy, 25 * pulse);
          starGrad.addColorStop(0, '#ffffff');
          starGrad.addColorStop(0.2, '#fde047');
          starGrad.addColorStop(1, 'rgba(250, 204, 21, 0)');
          ctx.fillStyle = starGrad;
          ctx.beginPath();
          ctx.arc(sx, sy, 30 * pulse, 0, Math.PI*2);
          ctx.fill();
      });
  };

  const drawCypressTree = (ctx: CanvasRenderingContext2D, h: number) => {
      ctx.fillStyle = '#020617'; 
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.quadraticCurveTo(50, h * 0.8, 30, h * 0.6);
      ctx.quadraticCurveTo(80, h * 0.5, 40, h * 0.3);
      ctx.quadraticCurveTo(60, h * 0.2, 35, h * 0.05); 
      ctx.quadraticCurveTo(80, h * 0.25, 70, h * 0.4);
      ctx.quadraticCurveTo(120, h * 0.6, 80, h * 0.8);
      ctx.quadraticCurveTo(150, h * 0.9, 100, h);
      ctx.fill();
  };

  const drawClassicNote = (ctx: CanvasRenderingContext2D, note: SongNote, x: number, y: number, w: number, h: number, isBlack: boolean, isBlocking: boolean, isAuto: boolean) => {
      let mainColor, glowColor;
      if (isBlocking) {
          const flash = Math.floor(performance.now() / 100) % 2 === 0;
          mainColor = flash ? '#ffffff' : '#f59e0b'; 
          glowColor = '#d97706';
      } else if (isAuto) {
          if (isBlack) { mainColor = '#f472b6'; glowColor = '#db2777'; } 
          else { mainColor = '#f9a8d4'; glowColor = '#ec4899'; }
      } else {
          if (isBlack) { mainColor = '#2dd4bf'; glowColor = '#14b8a6'; } 
          else { mainColor = '#60a5fa'; glowColor = '#3b82f6'; }
      }

      const totalDurationLen = note.duration * NOTE_SPEED;
      if (totalDurationLen > h * 1.2) {
          const tailLen = totalDurationLen - h;
          const tailGrad = ctx.createLinearGradient(0, y - tailLen, 0, y);
          tailGrad.addColorStop(0, 'rgba(255,255,255,0)');
          tailGrad.addColorStop(0.8, mainColor);
          ctx.fillStyle = tailGrad;
          const tailW = Math.max(2, w * 0.3);
          ctx.fillRect(x + (w - tailW)/2, y - tailLen, tailW, tailLen);
      }

      ctx.shadowBlur = isBlocking ? 30 : 15;
      ctx.shadowColor = glowColor;
      ctx.fillStyle = mainColor;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, 6);
      ctx.fill();
      ctx.shadowBlur = 0;
  };

  const drawNeonNote = (ctx: CanvasRenderingContext2D, note: SongNote, x: number, y: number, w: number, h: number, isBlack: boolean, isBlocking: boolean, isAuto: boolean) => {
      let borderColor, innerColor;
      if (isBlocking) {
          borderColor = '#ffff00';
          innerColor = '#ffff00';
      } else if (isAuto) {
          borderColor = '#ff00ff'; // Magenta
          innerColor = 'rgba(255, 0, 255, 0.3)';
      } else {
          if (isBlack) {
              borderColor = '#00f3ff'; // Cyan
              innerColor = 'rgba(0, 243, 255, 0.3)';
          } else {
              borderColor = '#bc13fe'; // Electric Purple
              innerColor = 'rgba(188, 19, 254, 0.3)';
          }
      }

      const totalDurationLen = note.duration * NOTE_SPEED;
      if (totalDurationLen > h * 1.2) {
          const tailLen = totalDurationLen - h;
          ctx.strokeStyle = borderColor;
          ctx.lineWidth = 2;
          ctx.shadowBlur = 10;
          ctx.shadowColor = borderColor;
          ctx.beginPath();
          ctx.moveTo(x + w/2, y);
          ctx.lineTo(x + w/2, y - tailLen);
          ctx.stroke();
          ctx.shadowBlur = 0;
      }

      ctx.lineWidth = 3;
      ctx.strokeStyle = borderColor;
      ctx.fillStyle = innerColor;
      ctx.shadowColor = borderColor;
      ctx.shadowBlur = 15;
      
      ctx.beginPath();
      ctx.moveTo(x + 5, y);
      ctx.lineTo(x + w - 5, y);
      ctx.lineTo(x + w, y + h/2);
      ctx.lineTo(x + w - 5, y + h);
      ctx.lineTo(x + 5, y + h);
      ctx.lineTo(x, y + h/2);
      ctx.closePath();
      
      ctx.fill();
      ctx.stroke();
      
      ctx.fillStyle = '#ffffff';
      ctx.globalAlpha = 0.8;
      ctx.beginPath();
      ctx.arc(x + w*0.2, y + h*0.3, 2, 0, Math.PI*2);
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.shadowBlur = 0;
  };

  const drawProceduralFruit = (ctx: CanvasRenderingContext2D, type: FruitType, cx: number, cy: number, radius: number) => {
      const colors = getFruitColors(type);
      ctx.shadowColor = 'rgba(0,0,0,0.3)';
      ctx.shadowBlur = 15;
      ctx.shadowOffsetY = 8;

      if (type === 'watermelon') {
          ctx.fillStyle = colors.skin;
          ctx.beginPath();
          ctx.arc(cx, cy, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = colors.detail;
          ctx.lineWidth = radius / 4;
          ctx.beginPath();
          ctx.moveTo(cx - radius/2, cy - radius*0.8);
          ctx.quadraticCurveTo(cx, cy, cx + radius/2, cy + radius*0.8);
          ctx.moveTo(cx + radius/2, cy - radius*0.8);
          ctx.quadraticCurveTo(cx, cy, cx - radius/2, cy + radius*0.8);
          ctx.stroke();
      } else if (type === 'orange') {
          ctx.fillStyle = colors.skin;
          ctx.beginPath();
          ctx.arc(cx, cy, radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = colors.detail;
          for(let i=0; i<3; i++) {
              ctx.beginPath();
              ctx.arc(cx + (Math.random()-0.5)*radius, cy + (Math.random()-0.5)*radius, 1, 0, Math.PI*2);
              ctx.fill();
          }
          ctx.fillStyle = '#166534';
          ctx.beginPath();
          ctx.arc(cx, cy - radius + 2, 3, 0, Math.PI * 2);
          ctx.fill();
      } else if (type === 'lemon') {
          ctx.fillStyle = colors.skin;
          ctx.beginPath();
          ctx.ellipse(cx, cy, radius * 0.8, radius, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(cx, cy - radius + 2, 4, 0, Math.PI * 2);
          ctx.arc(cx, cy + radius - 2, 3, 0, Math.PI * 2);
          ctx.fill();
      } else if (type === 'apple') {
          ctx.fillStyle = colors.skin;
          ctx.beginPath();
          const r = radius;
          ctx.moveTo(cx, cy - r*0.4); 
          ctx.bezierCurveTo(cx - r, cy - r, cx - r, cy + r, cx, cy + r); 
          ctx.bezierCurveTo(cx + r, cy + r, cx + r, cy - r, cx, cy - r*0.4); 
          ctx.fill();
          ctx.strokeStyle = '#451a03';
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(cx, cy - r*0.4);
          ctx.quadraticCurveTo(cx + 2, cy - r*0.8, cx + 4, cy - r);
          ctx.stroke();
      } else if (type === 'blueberry') {
          ctx.fillStyle = colors.skin;
          ctx.beginPath();
          ctx.arc(cx, cy, radius * 0.8, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = colors.detail;
          ctx.beginPath();
          ctx.moveTo(cx - 3, cy - radius*0.5);
          ctx.lineTo(cx + 3, cy - radius*0.5);
          ctx.lineTo(cx, cy - radius*0.2);
          ctx.fill();
      }

      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.beginPath();
      ctx.ellipse(cx - radius*0.3, cy - radius*0.3, radius*0.2, radius*0.1, -Math.PI/4, 0, Math.PI*2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.shadowOffsetY = 0;
  };

  const drawFruitNote = (ctx: CanvasRenderingContext2D, note: SongNote, x: number, y: number, w: number, h: number, isBlack: boolean, isBlocking: boolean, isAuto: boolean) => {
      const totalDurationLen = note.duration * NOTE_SPEED;
      if (totalDurationLen > h * 1.2) {
          ctx.fillStyle = '#a3e635'; 
          ctx.fillRect(x + w/2 - 2, y - (totalDurationLen - h), 4, totalDurationLen - h);
      }

      const r = Math.min(w, h) / 2;
      const cx = x + w/2;
      const cy = y + h/2;
      
      const fruitType = getFruitType(note.midi);
      drawProceduralFruit(ctx, fruitType, cx, cy, r);
  };

  const drawStarryNote = (ctx: CanvasRenderingContext2D, note: SongNote, x: number, y: number, w: number, h: number, isBlack: boolean, isBlocking: boolean, isAuto: boolean) => {
       const totalDurationLen = note.duration * NOTE_SPEED;
       if (totalDurationLen > h * 1.2) {
           ctx.strokeStyle = '#fde047';
           ctx.lineWidth = 2;
           ctx.setLineDash([5, 5]);
           ctx.beginPath();
           ctx.moveTo(x + w/2, y);
           ctx.lineTo(x + w/2, y - (totalDurationLen - h));
           ctx.stroke();
           ctx.setLineDash([]);
       }

       const cx = x + w/2;
       const cy = y + h/2;
       const r = Math.min(w, h) / 1.5;

       const grad = ctx.createRadialGradient(cx, cy, r*0.2, cx, cy, r);
       grad.addColorStop(0, '#fff');
       grad.addColorStop(0.3, '#facc15'); // Yellow
       grad.addColorStop(1, 'rgba(234, 179, 8, 0)');

       ctx.fillStyle = grad;
       ctx.beginPath();
       ctx.arc(cx, cy, r, 0, Math.PI*2);
       ctx.fill();

       ctx.fillStyle = '#fef08a';
       ctx.beginPath();
       ctx.arc(cx, cy, r*0.4, 0, Math.PI*2);
       ctx.fill();
  };

  // --- DREAM NOTE (Capsule/Gem) ---
  const drawDreamNote = (ctx: CanvasRenderingContext2D, note: SongNote, x: number, y: number, w: number, h: number, isBlack: boolean, isBlocking: boolean, isAuto: boolean) => {
      const totalDurationLen = note.duration * NOTE_SPEED;
      
      // Glowing Trail
      if (totalDurationLen > h * 1.2) {
          const tailLen = totalDurationLen - h;
          const tailGrad = ctx.createLinearGradient(0, y - tailLen, 0, y);
          const color = isBlack ? 'rgba(244, 114, 182, 0)' : 'rgba(254, 202, 202, 0)';
          const colorSolid = isBlack ? 'rgba(244, 114, 182, 0.5)' : 'rgba(254, 202, 202, 0.5)';
          tailGrad.addColorStop(0, color);
          tailGrad.addColorStop(1, colorSolid);
          
          ctx.fillStyle = tailGrad;
          const tailW = Math.max(4, w * 0.4);
          ctx.beginPath();
          ctx.roundRect(x + (w - tailW)/2, y - tailLen, tailW, tailLen, 10);
          ctx.fill();
      }

      // Gemstone Note Head
      ctx.save();
      // Bloom
      ctx.shadowColor = isBlack ? '#ec4899' : '#fcd34d';
      ctx.shadowBlur = 20;
      
      const grad = ctx.createLinearGradient(x, y, x + w, y + h);
      if (isBlack) {
          grad.addColorStop(0, '#fbc2eb'); // Lavender
          grad.addColorStop(1, '#be185d'); // Deep Pink
      } else {
          grad.addColorStop(0, '#fff'); 
          grad.addColorStop(1, '#fcd34d'); // Gold
      }
      
      ctx.fillStyle = grad;
      ctx.beginPath();
      // Capsule shape
      ctx.roundRect(x, y, w, h, w/2);
      ctx.fill();
      
      // Highlight shine
      ctx.fillStyle = 'rgba(255,255,255,0.8)';
      ctx.beginPath();
      ctx.ellipse(x + w*0.3, y + h*0.3, w*0.2, h*0.15, -Math.PI/4, 0, Math.PI*2);
      ctx.fill();
      
      ctx.restore();
  };

  const drawKeys = (ctx: CanvasRenderingContext2D, width: number, height: number, state: any, keyTopY: number, scale: number, theme: ThemeMode) => {
      // White Keys
      for (let m = MIN_MIDI; m <= MAX_MIDI; m++) {
        const worldX = getWorldNoteX(m, width);
        const worldW = getWorldNoteWidth(m, width);
        const screenX = toScreenX(worldX);
        const screenW = worldW * scale;
        
        if (screenX + screenW < -50 || screenX > width + 50) continue;
        
        const isBlack = isBlackKey(m);
        const isActive = state.activeKeys.has(m);
        const isAutoHeld = state.activeAutoKeys.has(m);

        if (!isBlack) {
          if (theme === 'neon') {
            // NEON Logic...
            const inactiveFill = 'rgba(30, 10, 50, 0.8)';
            const inactiveStroke = 'rgba(188, 19, 254, 0.4)';
            ctx.fillStyle = isActive ? (isAutoHeld ? '#ff00ff' : '#bc13fe') : inactiveFill;
            ctx.strokeStyle = isActive ? '#ffffff' : inactiveStroke;
            ctx.lineWidth = isActive ? 2 : 1;
            if (isActive) {
                ctx.shadowColor = isAutoHeld ? '#ff00ff' : '#bc13fe';
                ctx.shadowBlur = 30;
            } else {
                ctx.shadowBlur = 0;
            }
            ctx.fillRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
            ctx.strokeRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
            ctx.shadowBlur = 0;
          } else if (theme === 'fruit') {
             // FRUIT Logic...
             if (isActive) {
                 const grad = ctx.createLinearGradient(screenX, keyTopY, screenX, height);
                 grad.addColorStop(0, '#fb7185'); 
                 grad.addColorStop(1, '#e11d48'); 
                 ctx.fillStyle = grad;
             } else {
                 ctx.fillStyle = 'rgba(255, 255, 255, 0.7)'; 
             }
             ctx.fillRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
             ctx.strokeStyle = 'rgba(255,255,255,0.5)';
             ctx.lineWidth = 1;
             ctx.strokeRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
          } else if (theme === 'starry') {
             ctx.fillStyle = isActive ? '#facc15' : '#1e3a8a'; 
             ctx.strokeStyle = '#1e40af';
             ctx.lineWidth = 1;
             ctx.fillRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
             ctx.strokeRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
          } else if (theme === 'dream') {
             // DREAM Keys (Rose Quartz/Crystal)
             if (isActive) {
                 const grad = ctx.createLinearGradient(screenX, keyTopY, screenX, height);
                 grad.addColorStop(0, '#fff'); 
                 grad.addColorStop(1, '#fce7f3'); // Light Pink
                 ctx.fillStyle = grad;
                 ctx.shadowColor = '#fbcfe8';
                 ctx.shadowBlur = 20;
             } else {
                 // Semi-transparent milky white
                 ctx.fillStyle = 'rgba(255, 240, 245, 0.5)'; 
                 ctx.shadowBlur = 0;
             }
             ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
             ctx.lineWidth = 1;
             // Rounded bottom
             ctx.beginPath();
             ctx.roundRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT, [0,0,8,8]);
             ctx.fill();
             ctx.stroke();
             ctx.shadowBlur = 0;
          } else {
            // Classic
            ctx.fillStyle = isActive ? (isAutoHeld ? '#fce7f3' : '#dbeafe') : '#f8fafc';
            if (isActive) {
                ctx.shadowColor = isAutoHeld ? '#ec4899' : '#60a5fa';
                ctx.shadowBlur = 20;
            }
            ctx.fillRect(screenX + 1, keyTopY, screenW - 2, KEY_HEIGHT);
            ctx.shadowBlur = 0;
          }

          // Label Visibility Check
          if (scale > 0.6 || isActive) {
                ctx.fillStyle = theme === 'neon' || theme === 'starry' ? '#fff' : (theme === 'fruit' ? '#9f1239' : (theme === 'dream' ? '#be185d' : '#000')); 
                if (isActive && theme === 'starry') ctx.fillStyle = '#000'; 
                ctx.font = `bold ${Math.min(16, screenW * 0.4)}px sans-serif`;
                ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
                ctx.fillText(getNoteName(m), screenX + screenW/2, height - 15);
           }
        }
      }
      
      // Black Keys
      for (let m = MIN_MIDI; m <= MAX_MIDI; m++) {
        if (isBlackKey(m)) {
          const worldX = getWorldNoteX(m, width);
          const worldW = getWorldNoteWidth(m, width);
          const screenX = toScreenX(worldX);
          const screenW = worldW * scale;
          if (screenX + screenW < -50 || screenX > width + 50) continue;
          
          const isActive = state.activeKeys.has(m);
          const isAutoHeld = state.activeAutoKeys.has(m);
          const h = KEY_HEIGHT * 0.65;
          
          if (theme === 'neon') {
              // NEON Logic...
              const inactiveFill = '#050510'; 
              const inactiveStroke = 'rgba(0, 243, 255, 0.3)';
              if (isActive) {
                  ctx.fillStyle = isAutoHeld ? '#ff00ff' : '#00f3ff';
                  ctx.shadowColor = isAutoHeld ? '#ff00ff' : '#00f3ff';
                  ctx.shadowBlur = 30;
                  ctx.strokeStyle = '#ffffff';
              } else {
                  ctx.fillStyle = inactiveFill;
                  ctx.shadowBlur = 0;
                  ctx.strokeStyle = inactiveStroke;
              }
              ctx.lineWidth = isActive ? 2 : 1;
              ctx.beginPath();
              ctx.rect(screenX, keyTopY, screenW, h);
              ctx.fill();
              ctx.stroke();
              ctx.shadowBlur = 0;
          } else if (theme === 'fruit') {
              // FRUIT Logic...
              ctx.fillStyle = isActive ? '#84cc16' : '#14532d'; 
              if (!isActive) {
                  const grad = ctx.createLinearGradient(screenX, keyTopY, screenX + screenW, keyTopY);
                  grad.addColorStop(0, '#052e16');
                  grad.addColorStop(0.3, '#14532d');
                  grad.addColorStop(0.5, '#166534');
                  grad.addColorStop(0.7, '#14532d');
                  grad.addColorStop(1, '#052e16');
                  ctx.fillStyle = grad;
              }
              ctx.beginPath();
              ctx.roundRect(screenX, keyTopY, screenW, h, [0,0,4,4]);
              ctx.fill();
          } else if (theme === 'starry') {
              ctx.fillStyle = isActive ? '#facc15' : '#020617';
              ctx.strokeStyle = '#facc15';
              ctx.lineWidth = 1;
              ctx.fillRect(screenX, keyTopY, screenW, h);
              ctx.strokeRect(screenX, keyTopY, screenW, h);
          } else if (theme === 'dream') {
              // DREAM Keys (Amethyst)
              ctx.fillStyle = isActive ? '#f0abfc' : 'rgba(88, 28, 135, 0.8)'; // Bright purple vs Deep Purple
              if (isActive) {
                   ctx.shadowColor = '#d8b4fe';
                   ctx.shadowBlur = 20;
              }
              ctx.strokeStyle = 'rgba(255,255,255,0.2)';
              ctx.beginPath();
              ctx.roundRect(screenX, keyTopY, screenW, h, [0,0,6,6]);
              ctx.fill();
              ctx.stroke();
              ctx.shadowBlur = 0;
          } else {
              // Classic
              ctx.fillStyle = 'rgba(0,0,0,0.5)';
              ctx.fillRect(screenX + 4, keyTopY + 4, screenW, h);
              const grad = ctx.createLinearGradient(screenX, keyTopY, screenX, keyTopY + h);
              if (isActive) {
                 if (isAutoHeld) { grad.addColorStop(0, '#f472b6'); grad.addColorStop(1, '#be185d'); ctx.shadowColor = '#f472b6'; } 
                 else { grad.addColorStop(0, '#2dd4bf'); grad.addColorStop(1, '#0f766e'); ctx.shadowColor = '#2dd4bf'; }
                 ctx.shadowBlur = 20;
              } else {
                 grad.addColorStop(0, '#334155'); grad.addColorStop(1, '#0f172a');
              }
              ctx.fillStyle = grad;
              ctx.beginPath();
              ctx.roundRect(screenX, keyTopY, screenW, h, [0,0,6,6]);
              ctx.fill();
              ctx.shadowBlur = 0;
          }
        }
      }
  };

  const drawEffects = (ctx: CanvasRenderingContext2D, state: any, keyTopY: number, dt: number) => {
      state.effects = state.effects.filter((eff: VisualEffect) => {
        const age = (performance.now() / 1000) - eff.startTime;
        const life = eff.life || 1.0;
        if (age > life) return false;

        const progress = age / life;
        const screenX = toScreenX(eff.worldX);
        
        if (eff.type === 'hit-particle' || eff.type === 'juice' || eff.type === 'fairy-dust') {
           eff.x = (eff.vx || 0) * age; 
           const gravity = (eff.type === 'fairy-dust' ? -50 : 800) * age * age; // Fairy dust floats UP sometimes
           eff.y = (eff.vy || 0) * age + gravity;
           const x = screenX + eff.x;
           const y = (keyTopY - 20) + eff.y;
           
           ctx.globalCompositeOperation = 'lighter';
           ctx.globalAlpha = 1 - Math.pow(progress, 2);
           ctx.fillStyle = eff.color;
           ctx.beginPath();
           ctx.arc(x, y, (eff.size || 3), 0, Math.PI * 2);
           ctx.fill();
           ctx.globalAlpha = 1;
           ctx.globalCompositeOperation = 'source-over';
           return true;
        }
        else if (eff.type === 'bloom-ring') {
            const r = (eff.size || 30) * (0.5 + progress * 2);
            ctx.globalCompositeOperation = 'screen';
            ctx.strokeStyle = eff.color;
            ctx.lineWidth = 2 * (1 - progress);
            ctx.globalAlpha = 1 - progress;
            ctx.beginPath();
            ctx.arc(screenX, eff.y, r, 0, Math.PI * 2);
            ctx.stroke();
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = 'source-over';
            return true;
        }
        else if (eff.type === 'sliced-fruit') {
            // Fruit Ninja logic (same as before)
            if (eff.vy !== undefined) eff.vy += 1000 * dt;
            if (eff.vx !== undefined) eff.x += eff.vx * dt;
            if (eff.vy !== undefined) eff.y += eff.vy * dt;
            if (eff.rotation !== undefined && eff.rotationSpeed !== undefined) eff.rotation += eff.rotationSpeed * dt;
            const x = screenX + (eff.x || 0);
            const y = (keyTopY) + (eff.y || 0);
            const size = eff.size || 20;
            const colors = getFruitColors(eff.fruitType || 'orange');
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(eff.rotation || 0);
            ctx.shadowColor = 'rgba(0,0,0,0.3)';
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(0, 0, size, 0, Math.PI, true); 
            ctx.closePath();
            ctx.fillStyle = colors.skin;
            ctx.fill();
            ctx.shadowBlur = 0; 
            ctx.fillStyle = colors.flesh;
            ctx.beginPath();
            ctx.moveTo(-size, 0);
            ctx.lineTo(size, 0);
            ctx.bezierCurveTo(size*0.5, size*0.2, -size*0.5, size*0.2, -size, 0);
            ctx.fill();
            ctx.restore();
            return true;
        }
        else if (eff.type === 'paint-swirl') {
            const x = screenX;
            const y = keyTopY;
            const size = (eff.size || 40) * (0.5 + progress);
            const rotation = progress * Math.PI;
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(rotation);
            ctx.globalAlpha = 1 - progress;
            ctx.strokeStyle = eff.color;
            ctx.lineWidth = 4;
            ctx.beginPath();
            for(let i=0; i<20; i++) {
                const angle = 0.1 * i;
                const r = size * (i/20);
                ctx.lineTo(Math.cos(angle * 5) * r, Math.sin(angle * 5) * r);
            }
            ctx.stroke();
            ctx.restore();
            return true;
        }
        else if (eff.type === 'shockwave') {
           const maxR = 120;
           const r = maxR * Math.sin(progress * Math.PI / 2);
           const alpha = 1 - progress;
           ctx.globalCompositeOperation = 'lighter';
           ctx.strokeStyle = eff.color;
           ctx.lineWidth = 4 * (1 - progress);
           ctx.globalAlpha = alpha;
           ctx.beginPath();
           ctx.ellipse(screenX, eff.y, r, r * 0.3, 0, 0, Math.PI * 2);
           ctx.stroke();
           ctx.globalAlpha = 1;
           ctx.globalCompositeOperation = 'source-over';
           return true;
        }
        else if (eff.type === 'slash') {
            if (theme !== 'fruit') ctx.globalCompositeOperation = 'lighter';
            ctx.strokeStyle = eff.color;
            ctx.lineWidth = 4 * (1 - progress); 
            ctx.globalAlpha = 1 - Math.pow(progress, 4); 
            const size = (eff.size || 100) * (0.8 + progress * 0.2);
            const angle = eff.angle || 0;
            const x1 = screenX - Math.cos(angle) * size/2;
            const y1 = eff.y - Math.sin(angle) * size/2;
            const x2 = screenX + Math.cos(angle) * size/2;
            const y2 = eff.y + Math.sin(angle) * size/2;
            if (theme !== 'fruit') {
                ctx.shadowColor = 'white';
                ctx.shadowBlur = 15;
            }
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
            ctx.globalAlpha = 1;
            ctx.shadowBlur = 0;
            ctx.globalCompositeOperation = 'source-over';
            return true;
        }
        else if (eff.type === 'shatter') {
            const g = 1000; 
            if (eff.vy !== undefined) eff.vy += g * dt;
            if (eff.vx !== undefined) eff.x += eff.vx * dt;
            if (eff.vy !== undefined) eff.y += eff.vy * dt;
            if (eff.rotation !== undefined && eff.rotationSpeed !== undefined) eff.rotation += eff.rotationSpeed * dt;
            const x = screenX + (eff.x || 0);
            const y = (keyTopY) + (eff.y || 0);
            if (theme !== 'fruit') ctx.globalCompositeOperation = 'lighter';
            ctx.globalAlpha = 1 - Math.pow(progress, 2);
            ctx.fillStyle = eff.color;
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(eff.rotation || 0);
            const s = eff.size || 5;
            ctx.beginPath();
            ctx.moveTo(0, -s);
            ctx.lineTo(s, s);
            ctx.lineTo(-s, s);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
            ctx.globalAlpha = 1;
            ctx.globalCompositeOperation = 'source-over';
            return true;
        }
        return false;
      });
  };

  const drawMinimap = (ctx: CanvasRenderingContext2D, width: number, state: any, isAutoPlay: boolean, isWaitMode: boolean, theme: ThemeMode) => {
      ctx.clearRect(0, 0, MINIMAP_WIDTH, MINIMAP_HEIGHT);
      
      // Minimap bg
      if (theme === 'fruit') {
          ctx.fillStyle = 'rgba(251, 113, 133, 0.9)'; 
      } else if (theme === 'dream') {
          ctx.fillStyle = 'rgba(168, 85, 247, 0.9)'; // Purple
      } else {
          ctx.fillStyle = theme === 'classic' ? 'rgba(15, 23, 42, 0.95)' : 'rgba(0,0,0,0.8)';
      }
      ctx.fillRect(0, 0, MINIMAP_WIDTH, MINIMAP_HEIGHT);
      
      const miniKeyW = MINIMAP_WIDTH / TOTAL_KEYS;

      state.notes.forEach((note: SongNote) => {
         if (note.state === NoteState.Hit) return;
         const timeDiff = note.startTime - state.songProgress;
         if (timeDiff < -2 || timeDiff > MINIMAP_LOOKAHEAD) return;

         const midiIndex = note.midi - MIN_MIDI;
         const mx = midiIndex * miniKeyW;
         const normTime = Math.max(0, timeDiff) / MINIMAP_LOOKAHEAD;
         const my = MINIMAP_HEIGHT - (normTime * MINIMAP_HEIGHT);
         
         if (isAutoPlay) {
             ctx.fillStyle = isBlackKey(note.midi) ? '#db2777' : '#f472b6';
         } else {
             if (theme === 'neon') {
                 ctx.fillStyle = isBlackKey(note.midi) ? '#00f3ff' : '#bc13fe';
             } else if (theme === 'fruit') {
                 ctx.fillStyle = '#fef08a'; 
             } else if (theme === 'starry') {
                 ctx.fillStyle = '#facc15';
             } else if (theme === 'dream') {
                 ctx.fillStyle = isBlackKey(note.midi) ? '#fff' : '#fcd34d';
             } else {
                 ctx.fillStyle = isBlackKey(note.midi) ? '#2dd4bf' : '#60a5fa';
             }
         }
         ctx.fillRect(mx, my, Math.max(miniKeyW, 2), 3);
      });

      ctx.strokeStyle = isWaitMode && state.isWaiting ? '#facc15' : (isAutoPlay ? '#ec4899' : (theme === 'fruit' ? '#fef08a' : '#ffffff'));
      ctx.lineWidth = (isWaitMode && state.isWaiting) || isAutoPlay ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(0, MINIMAP_HEIGHT);
      ctx.lineTo(MINIMAP_WIDTH, MINIMAP_HEIGHT);
      ctx.stroke();

      const mapScale = MINIMAP_WIDTH / width; 
      const viewportWorldLeft = -viewRef.current.offsetX / viewRef.current.scale;
      const viewportWorldWidth = width / viewRef.current.scale;
      const boxX = viewportWorldLeft * mapScale;
      const boxW = viewportWorldWidth * mapScale;

      ctx.strokeStyle = isAutoPlay ? '#ec4899' : (theme === 'fruit' ? '#a3e635' : (theme === 'dream' ? '#fff' : '#facc15'));
      ctx.lineWidth = 2;
      ctx.strokeRect(boxX, 0, boxW, MINIMAP_HEIGHT);
  };

  // Resize Handler
  useEffect(() => {
    const handleResize = () => {
      if (canvasRef.current) {
        const dpr = window.devicePixelRatio || 1;
        const w = window.innerWidth;
        const h = window.innerHeight;
        canvasRef.current.width = w * dpr;
        canvasRef.current.height = h * dpr;
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) ctx.scale(dpr, dpr);
        setCanvasSize({ width: w, height: h });
      }
      if (minimapRef.current) {
         const dpr = window.devicePixelRatio || 1;
         minimapRef.current.width = MINIMAP_WIDTH * dpr;
         minimapRef.current.height = MINIMAP_HEIGHT * dpr;
         const ctx = minimapRef.current.getContext('2d');
         if (ctx) ctx.scale(dpr, dpr);
      }
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleMinimapInteraction = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const minimap = minimapRef.current;
    if (!minimap) return;
    const rect = minimap.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = Math.max(0, Math.min(1, clickX / rect.width));
    const targetWorldX = ratio * canvasSize.width;
    const newOffsetX = (canvasSize.width / 2) - (targetWorldX * viewRef.current.scale);
    viewRef.current.offsetX = newOffsetX;
  };

  return (
    <>
      <canvas 
        ref={canvasRef}
        className="absolute top-0 left-0 z-0 touch-none cursor-pointer"
        style={{ width: '100%', height: '100%' }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        onPointerLeave={handlePointerUp}
      />
      
      <div 
        className={`absolute top-6 right-6 z-30 rounded-lg border shadow-2xl overflow-hidden backdrop-blur-sm hidden md:block ${theme === 'fruit' ? 'bg-rose-100/80 border-rose-300 shadow-rose-500/30' : (theme === 'dream' ? 'bg-purple-500/20 border-purple-300/50 shadow-purple-500/30' : 'bg-black/80 border-slate-600/50')}`}
        style={{ width: MINIMAP_WIDTH, height: MINIMAP_HEIGHT }}
      >
         <canvas
            ref={minimapRef}
            style={{ width: '100%', height: '100%' }}
            className="cursor-crosshair touch-none block"
            onPointerDown={handleMinimapInteraction}
            onPointerMove={(e) => e.buttons === 1 && handleMinimapInteraction(e)}
         />
         <div className={`absolute top-1 left-2 text-[9px] font-mono font-bold pointer-events-none select-none tracking-widest flex gap-2 ${theme === 'fruit' ? 'text-rose-700' : (theme === 'dream' ? 'text-white shadow-black/20 drop-shadow-md' : 'text-slate-400')}`}>
            <span>全览小地图</span>
            {isWaitMode && !isAutoPlay && <span className="text-amber-500 animate-pulse">等待模式开启</span>}
            {isAutoPlay && <span className="text-pink-500 animate-pulse">AI 托管中</span>}
         </div>
      </div>
    </>
  );
};
