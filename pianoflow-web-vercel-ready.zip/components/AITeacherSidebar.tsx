
import React, { useState, useRef, useEffect } from 'react';
import { Send, X, Sparkles, GraduationCap, Loader2, PlayCircle, BookOpen, MessageSquare, LayoutList, ChevronRight, Music, Activity, Layers, BookOpenText, Heart, Check, Volume2, Square, Keyboard, Globe } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import * as Tone from 'tone';
import { AiGeneratedExercise, AnalysisPayload, SongNote, NoteState } from '../types';
import { audioService } from '../services/audioService';

interface AITeacherSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadExercise: (exercise: AiGeneratedExercise, mode: 'full' | 'piano') => void;
  onSaveExercise: (exercise: AiGeneratedExercise) => void;
  analysisData: AnalysisPayload | null;
  onAnalysisComplete: () => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  exerciseData?: AiGeneratedExercise; 
  isSaved?: boolean;
  groundingMetadata?: any; // Store search sources if available
}

type CourseCategoryType = '基础入门' | '核心技巧' | '乐理伴奏' | '经典名曲';

interface Course {
  id: string;
  title: string;
  description: string;
  level: '入门' | '初级' | '进阶' | '挑战';
  icon: string;
  prompt: string;
  category: CourseCategoryType;
}

const COURSES: Course[] = [
  {
    id: 'b-1',
    category: '基础入门',
    title: '第一课：坐姿与手型',
    description: '学习钢琴演奏的“地基”：标准坐姿与握球状手型。',
    level: '入门',
    icon: '🧘',
    prompt: '我想学习【第一课：坐姿与手型】。请详细讲解正确的钢琴坐姿、手型（握球状），并给我一个非常简单的单手练习来通过按键感受重量（非手指发力）。'
  },
  {
    id: 'b-2',
    category: '基础入门',
    title: '第二课：认识键盘',
    description: '利用黑键规律（2+3）快速定位所有音符。',
    level: '入门',
    icon: '🎹',
    prompt: '我想学习【第二课：认识键盘与中央C】。请教我如何利用黑键（2个一组和3个一组）快速找到中央C，并生成一个跨越几个八度寻找C音的练习。'
  },
  {
    id: 'b-3',
    category: '基础入门',
    title: '第三课：节奏基础',
    description: '全音符、四分音符与休止符的实战训练。',
    level: '入门',
    icon: '🥁',
    prompt: '我想学习【第三课：节奏感特训】。请解释全音符、二分音符和四分音符的区别，并生成一个只包含简单音高（如CDE）但节奏变化丰富的练习曲。'
  },
  {
    id: 't-1',
    category: '核心技巧',
    title: '五指独立性 (哈农No.1)',
    description: '激活手指机能，特别是弱指（无名指与小指）。',
    level: '初级',
    icon: '🖐️',
    prompt: '我想学习【技巧：五指独立性】。请生成一段类似《哈农》第一首的练习，重点训练手指的高抬指和独立性，特别是4指和5指。'
  },
  {
    id: 't-2',
    category: '核心技巧',
    title: '音阶特训：穿指法',
    description: '学习长音阶演奏的核心技巧：大拇指穿行 (Thumb Under)。',
    level: '进阶',
    icon: '🔄',
    prompt: '我想学习【技巧：穿指法】。这是弹奏长音阶的关键。请讲解什么是“穿指” (Thumb Under)，并生成一个 C 大调音阶的上行练习，包含穿指动作。'
  },
  {
    id: 't-3',
    category: '核心技巧',
    title: '双管齐下：双手配合',
    description: '左右手演奏不同旋律的协调性入门。',
    level: '进阶',
    icon: '🤝',
    prompt: '我想学习【技巧：双手配合】。请生成一个练习，左手弹奏简单的长音伴奏，右手弹奏旋律，帮我练习双手的协调性。'
  },
  {
    id: 'th-1',
    category: '乐理伴奏',
    title: '三和弦的秘密',
    description: '大三和弦与小三和弦的构建原理。',
    level: '初级',
    icon: '🎼',
    prompt: '我想学习【乐理：三和弦】。请讲解大三和弦(Major)和小三和弦(Minor)的构成区别（大三度+小三度），并生成一个包含C、F、G、Am和弦的练习。'
  },
  {
    id: 'th-2',
    category: '乐理伴奏',
    title: '流行万能和弦',
    description: '学会 4536 或 1564 进行，弹奏 80% 的流行歌。',
    level: '进阶',
    icon: '🎸',
    prompt: '我想学习【伴奏：流行万能和弦】。请教我 C-G-Am-F (1-5-6-4) 这个黄金和弦进行，并生成一个左手柱式和弦的伴奏练习。'
  },
  {
    id: 'th-3',
    category: '乐理伴奏',
    title: '分解和弦 (Arpeggio)',
    description: '让伴奏流动起来的技巧，如《月光奏鸣曲》。',
    level: '进阶',
    icon: '🌊',
    prompt: '我想学习【伴奏：分解和弦】。请教我如何将柱式和弦拆解为流动的分解和弦（Arpeggio），并生成一个优美的分解和弦练习曲。'
  },
  {
    id: 's-1',
    category: '经典名曲',
    title: '欢乐颂 (Ode to Joy)',
    description: '贝多芬第九交响曲主题，宏大而简单的旋律。',
    level: '初级',
    icon: '🏰',
    prompt: '我想学习【名曲：欢乐颂】。请为我生成贝多芬《欢乐颂》的主题旋律练习谱，并简要介绍这首曲子的背景。'
  },
  {
    id: 's-2',
    category: '经典名曲',
    title: '致爱丽丝 (Für Elise)',
    description: '贝多芬最著名的钢琴小品，右手流动的半音阶。',
    level: '进阶',
    icon: '📜',
    prompt: '我想学习【名曲：致爱丽丝】。请教我这首曲子最著名的右手主题段落（E-D#-E-D#-E-B-D-C-A...），并生成对应的练习谱。'
  },
  {
    id: 's-3',
    category: '经典名曲',
    title: '卡农 (Canon in D)',
    description: '帕赫贝尔的传世之作，感受完美的循环和声。',
    level: '进阶',
    icon: '🎻',
    prompt: '我想学习【名曲：卡农】。请为我生成 D大调卡农 的核心旋律练习，如果是初学者可以适当简化为 C 大调，重点感受那种循环的美感。'
  },
  {
    id: 's-4',
    category: '经典名曲',
    title: '天空之城 (Castle in the Sky)',
    description: '久石让经典配乐，优美伤感的旋律。',
    level: '进阶',
    icon: '☁️',
    prompt: '我想学习【名曲：天空之城】。请为我生成久石让《天空之城》副歌部分的高潮旋律练习谱。'
  },
  {
    id: 's-5',
    category: '经典名曲',
    title: '土耳其进行曲 (Rondo Alla Turca)',
    description: '莫扎特名曲，极具挑战的快速节奏训练。',
    level: '挑战',
    icon: '⚔️',
    prompt: '我想挑战【名曲：土耳其进行曲】。虽然很难，请截取莫扎特《土耳其进行曲》最著名的主旋律片段生成练习谱，让我慢速练习。'
  },
  {
    id: 's-6',
    category: '经典名曲',
    title: '月光奏鸣曲 (Moonlight Sonata)',
    description: '贝多芬第一乐章，极度考验力度的控制。',
    level: '挑战',
    icon: '🌙',
    prompt: '我想挑战【名曲：月光奏鸣曲】。请生成第一乐章标志性的三连音伴奏片段，教我如何控制手指力度，弹得轻柔而连贯。'
  }
];

const CATEGORIES: { id: CourseCategoryType; icon: any; label: string }[] = [
  { id: '基础入门', icon: BookOpenText, label: '入门' },
  { id: '核心技巧', icon: Activity, label: '技巧' },
  { id: '乐理伴奏', icon: Layers, label: '乐理' },
  { id: '经典名曲', icon: Music, label: '名曲' },
];

export const AITeacherSidebar: React.FC<AITeacherSidebarProps> = ({ 
  isOpen, 
  onClose, 
  onLoadExercise,
  onSaveExercise,
  analysisData,
  onAnalysisComplete
}) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'courses'>('chat');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState<string | null>(null);
  const [previewMsgId, setPreviewMsgId] = useState<string | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "你好！我是 Maestro。🎓\n\n我现在拥有 **联网搜索** 能力了！🌐\n\n告诉我你想弹什么歌（比如“周杰伦的晴天”或“克罗地亚狂想曲”），我会去网络上搜索它的原版乐谱、和弦与速度，为你生成最还原的 **完整版** 练习曲。\n\n请告诉我你想弹什么！"
    }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (activeTab === 'chat') {
      scrollToBottom();
    }
  }, [messages, isOpen, activeTab]);

  useEffect(() => {
    if (!isOpen) {
        audioService.stopAll();
        setPreviewMsgId(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (analysisData && !isLoading) {
      if (activeTab !== 'chat') setActiveTab('chat');
      triggerAnalysis(analysisData);
    }
  }, [analysisData]);

  const convertToPreviewNotes = (exercise: AiGeneratedExercise) => {
     const beatDur = 60 / exercise.bpm;
     let time = 0;
     const notes: SongNote[] = [];
     const backingNotes: SongNote[] = [];
     
     // Melody
     exercise.notes.forEach((n, i) => {
         const dur = n.duration * beatDur;
         if (n.note !== 'REST') {
              try {
                  notes.push({
                      id: `prev-${i}`,
                      midi: Tone.Frequency(n.note).toMidi(),
                      startTime: time,
                      duration: dur,
                      state: NoteState.Waiting
                  });
              } catch (e) {
                  console.warn("Invalid note for preview:", n.note);
              }
         }
         time += dur;
     });

     // Backing (Reset time)
     time = 0;
     if (exercise.backingNotes) {
         exercise.backingNotes.forEach((n, i) => {
             const dur = n.duration * beatDur;
             if (n.note !== 'REST') {
                 try {
                     backingNotes.push({
                         id: `prev-back-${i}`,
                         midi: Tone.Frequency(n.note).toMidi(),
                         startTime: time,
                         duration: dur,
                         state: NoteState.Waiting
                     });
                 } catch(e) {}
             }
             time += dur;
         });
     }

     return { notes, backingNotes };
  };

  const togglePreview = (e: React.MouseEvent, msgId: string, exercise: AiGeneratedExercise) => {
      e.stopPropagation();
      
      if (previewMsgId === msgId) {
          audioService.stopAll();
          setPreviewMsgId(null);
      } else {
          // Apply the preset first for preview!
          if (exercise.audioPreset) {
              audioService.applyPreset(exercise.audioPreset);
          } else {
              audioService.applyPreset('Standard');
          }

          const { notes, backingNotes } = convertToPreviewNotes(exercise);
          // Preview BOTH user notes (piano) and backing notes (synth)
          audioService.previewSong(notes, backingNotes);
          setPreviewMsgId(msgId);
      }
  };

  const triggerAnalysis = async (data: AnalysisPayload) => {
    setIsLoading(true);
    setSearchQuery(null);
    
    const totalHits = data.stats.hits.perfect + data.stats.hits.good + data.stats.hits.miss;
    const accuracy = totalHits > 0 
      ? Math.round(((data.stats.hits.perfect + data.stats.hits.good) / totalHits) * 100)
      : 0;

    const userDisplayMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: `请分析我刚刚的演奏表现：\n曲目: ${data.songTitle || '自由练习'}\n得分: ${data.stats.score}\n准确率: ${accuracy}%\nPerfect: ${data.stats.hits.perfect}\nGood: ${data.stats.hits.good}\nMiss: ${data.stats.hits.miss}`
    };
    setMessages(prev => [...prev, userDisplayMsg]);

    const prompt = `
      STATS: Score: ${data.stats.score}, Accuracy: ${accuracy}%
      Provide feedback and generate a remediation exercise in JSON.
      Respond in Simplified Chinese.
    `;

    await callGemini(prompt);
    onAnalysisComplete();
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userText = input;
    setInput('');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: userText }]);
    setIsLoading(true);
    
    // Heuristic to determine if we should show "Searching..." UI
    if (userText.length > 2 && !userText.includes("谢谢")) {
       setSearchQuery(`正在搜索 "${userText}" 的原版风格与编曲...`);
    }
    
    await callGemini(userText);
  };

  const handleStartCourse = async (course: Course) => {
    setActiveTab('chat');
    setMessages(prev => [...prev, { id: Date.now().toString(), role: 'user', text: `开始学习：${course.title}` }]);
    setIsLoading(true);
    setSearchQuery(null);
    await callGemini(course.prompt);
  };

  const handleSaveClick = (msgId: string, exercise: AiGeneratedExercise) => {
    onSaveExercise(exercise);
    setMessages(prev => prev.map(m => 
      m.id === msgId ? { ...m, isSaved: true } : m
    ));
  };

  const callGemini = async (promptContent: string) => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      // IMPROVED SYSTEM PROMPT WITH GENRE-SPECIFIC BACKING RULES AND COMPACT JSON
      const systemInstruction = `
        You are 'Maestro', an expert Music Composer and Piano Teacher.
        All your responses must be in **Simplified Chinese**.

        **CORE TASK: GLOBAL SEARCH & STYLE MATCHING**
        The user wants a "Full Song" that sounds like the **ORIGINAL**.
        Do NOT generate random accompaniment. You MUST match the song's specific **Rhythmic Vibe**.

        **WORKFLOW:**
        1. **SEARCH**: Use 'googleSearch' to find:
           - BPM & Key.
           - Main Melody (numbered notation/jianpu).
           - **GENRE / STYLE**: Is it a Ballad? Rock? Epic? Jazz?
        
        2. **BACKING TRACK GENERATION RULES (Crucial)**:
           - **Pop Ballad** (e.g., Pian Ai/偏爱, Someone Like You): 
             - Use **Arpeggios** or **Broken Chords** (e.g., 1-5-8-5 pattern).
             - *Must* sound fluid and emotional.
           - **Rock / Upbeat** (e.g., Yellow, Believer):
             - Use **Driving 8th Notes** (repeated Root-5th pulsing) or rhythmic chords.
             - It needs energy!
           - **Cinematic / Epic** (e.g., Interstellar, Pirates):
             - Use **Fast Arpeggios** or **Deep Long Bass Drones**.
           - **Classical**: Use **Alberti Bass** or traditional waltz patterns.

        **SPECIFIC INSTRUCTION FOR "PIAN AI" (偏爱)**:
        - **Genre**: Pop Rock / Chinese Xianxia Style.
        - **Backing**: Needs a **driving rhythm** in the chorus. Do NOT just use slow block chords. Use a pattern that mimics the guitar/bass drive (Root-5-8 rhythmic pattern).
        - **Structure**: Intro -> Verse (quieter) -> Chorus (High energy, thick texture).

        **JSON FORMAT RULES (CRITICAL - COMPACT MODE)**:
        - **LENGTH**: **2 to 3 Minutes** (Aim for 200-400 melody notes).
        - **STRUCTURE**: Intro -> Verse -> Chorus -> Bridge -> Outro.
        - **BACKING**: Must cover the entire duration.
        - **COMPACT ARRAYS**: To ensure the full song fits in the response, use ARRAYS for notes: \`["NoteName", Duration]\`.
          - Example: \`["C4", 1]\` instead of \`{"note": "C4", "duration": 1}\`.
        - **NO COMMENTS**: Do not add comments inside JSON.

        **MANDATORY JSON OUTPUT**:
        \`\`\`json
        {
          "title": "Song Title",
          "description": "Style: [Genre]. ...",
          "bpm": 120,
          "audioPreset": "Bright", 
          "notes": [ ["C4", 1], ["D4", 0.5], ["REST", 1], ... ],
          "backingNotes": [ ["C2", 2], ["G2", 2], ... ]
        }
        \`\`\`
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: promptContent,
        config: { 
            tools: [{ googleSearch: {} }], 
            systemInstruction,
            temperature: 0.5, 
            maxOutputTokens: 8192, 
        },
      });

      const rawText = response.text || "抱歉，我现在有点走神了，能再说一遍吗？";
      
      // Extract Grounding Metadata (Sources)
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

      const jsonMatch = rawText.match(/```json\s*([\s\S]*?)\s*```/);
      let exerciseData: AiGeneratedExercise | undefined;
      let displayText = rawText;

      if (jsonMatch) {
        try {
          const dirtyJson = jsonMatch[1];
          const cleanJson = dirtyJson
            .replace(/\/\/.*$/gm, '') 
            .replace(/\/\*[\s\S]*?\*\//g, '')
            .trim(); 
          
          let parsed: any;
          try {
             parsed = JSON.parse(cleanJson);
          } catch(e) {
             // Retry logic for common LLM JSON errors
             console.warn("Initial JSON parse failed, attempting repair...");
             // 1. Fix trailing commas before ] or }
             let fixed = cleanJson.replace(/,\s*([\]}])/g, '$1');
             
             // 2. If it looks truncated (doesn't end in }), try to close it roughly
             // Note: This is a desperate attempt, but with compact mode truncation is unlikely.
             if (!fixed.endsWith('}') && !fixed.endsWith(']')) {
                 fixed += ']}'; 
             }
             
             try {
                parsed = JSON.parse(fixed);
             } catch(e2) {
                 console.error("JSON Repair failed", e2);
                 throw e;
             }
          }

          // Transform compact arrays to objects
          if (parsed) {
             const transformNotes = (list: any[]) => {
                 if (!list) return [];
                 return list.map(item => {
                     // Handle ["C4", 1] format
                     if (Array.isArray(item) && item.length >= 2) {
                         return { note: item[0], duration: Number(item[1]) };
                     }
                     // Handle {"note": "C4", ...} format fallback
                     if (typeof item === 'object' && item !== null) return item;
                     return { note: 'REST', duration: 1 }; // Fallback
                 });
             };
             parsed.notes = transformNotes(parsed.notes);
             parsed.backingNotes = transformNotes(parsed.backingNotes);
             
             exerciseData = parsed;
          }

          displayText = rawText.replace(jsonMatch[0], '').trim();
          
          // Override presets based on specific titles if API missed it
          if (exerciseData) {
             const t = exerciseData.title.toLowerCase();
             if (t.includes("interstellar") || t.includes("星际")) exerciseData.audioPreset = "Cosmic";
             if (t.includes("pian ai") || t.includes("偏爱")) exerciseData.audioPreset = "Bright";
          }

        } catch (e) {
          console.error("Failed to parse AI exercise JSON", e);
          displayText += "\n\n(抱歉，生成的乐谱数据可能被截断或格式有误，请重试一次。)";
        }
      }

      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: displayText,
        exerciseData,
        groundingMetadata: groundingChunks
      }]);

    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: "网络连接似乎有点问题，请稍后再试。"
      }]);
    } finally {
      setIsLoading(false);
      setSearchQuery(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div 
      className={`fixed inset-y-0 right-0 w-96 bg-slate-900/95 backdrop-blur-xl border-l border-slate-700 shadow-2xl transform transition-transform duration-300 ease-in-out z-50 flex flex-col ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
    >
      <div className="p-4 border-b border-slate-700 bg-slate-800/50">
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2 text-sky-400">
            <GraduationCap size={24} />
            <div>
              <h2 className="font-bold text-lg leading-none">Maestro AI</h2>
              <span className="text-xs text-slate-400">智能钢琴导师 (联网版)</span>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white transition">
            <X size={20} />
          </button>
        </div>

        <div className="flex p-1 bg-slate-900 rounded-lg">
          <button 
            onClick={() => setActiveTab('chat')}
            className={`flex-1 py-1.5 text-sm font-medium rounded-md flex items-center justify-center gap-2 transition-all ${activeTab === 'chat' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <MessageSquare size={14} /> 
            <span className="relative">
               对话
               {messages.length > 1 && <span className="absolute -top-1 -right-2 w-2 h-2 bg-red-500 rounded-full"></span>}
            </span>
          </button>
          <button 
            onClick={() => setActiveTab('courses')}
            className={`flex-1 py-1.5 text-sm font-medium rounded-md flex items-center justify-center gap-2 transition-all ${activeTab === 'courses' ? 'bg-sky-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'}`}
          >
            <LayoutList size={14} /> 课程表
          </button>
        </div>
      </div>

      {activeTab === 'chat' && (
        <>
          <div className="flex-1 overflow-y-auto p-4 space-y-6 scrollbar-thin scrollbar-thumb-slate-700">
            {messages.map((msg) => (
              <div 
                key={msg.id} 
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div 
                  className={`max-w-[90%] p-4 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === 'user' 
                      ? 'bg-sky-600 text-white rounded-br-none shadow-lg shadow-sky-900/20' 
                      : 'bg-slate-800 text-slate-200 border border-slate-700 rounded-bl-none shadow-lg'
                  }`}
                >
                  {msg.role === 'model' && (
                    <div className="flex items-center gap-1 mb-2 text-xs text-sky-400 font-bold uppercase tracking-wide select-none">
                      <Sparkles size={12} /> Maestro
                    </div>
                  )}
                  {msg.text}
                  
                  {/* Show Sources/Grounding Info */}
                  {msg.groundingMetadata && (
                    <div className="mt-3 pt-2 border-t border-slate-600/50">
                        <div className="text-[10px] text-slate-400 font-bold uppercase mb-1 flex items-center gap-1">
                           <Globe size={10} /> 数据来源 (已参考)
                        </div>
                        <div className="flex flex-wrap gap-2">
                           {msg.groundingMetadata.map((chunk: any, idx: number) => {
                               if (chunk.web?.uri) {
                                   return (
                                       <a 
                                         key={idx} 
                                         href={chunk.web.uri} 
                                         target="_blank" 
                                         rel="noreferrer"
                                         className="text-[9px] px-2 py-0.5 bg-slate-900/50 rounded text-sky-400 hover:text-sky-300 hover:underline truncate max-w-[150px]"
                                       >
                                         {chunk.web.title || 'Web Source'}
                                       </a>
                                   )
                               }
                               return null;
                           })}
                        </div>
                    </div>
                  )}
                </div>

                {msg.exerciseData && (
                  <div className={`mt-3 max-w-[90%] bg-slate-800 rounded-xl overflow-hidden border shadow-lg shadow-sky-900/20 group cursor-pointer transition-all ${previewMsgId === msg.id ? 'border-sky-400 ring-1 ring-sky-400/50' : 'border-sky-500/30 hover:border-sky-500'}`}>
                    <div className="p-4 bg-gradient-to-br from-slate-800 to-slate-900">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <button 
                             onClick={(e) => togglePreview(e, msg.id, msg.exerciseData!)}
                             className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${previewMsgId === msg.id ? 'bg-sky-400 text-white animate-pulse' : 'bg-slate-700 text-sky-400 hover:bg-sky-600 hover:text-white'}`}
                             title="试听旋律 + 伴奏"
                          >
                              {previewMsgId === msg.id ? <Square size={12} fill="currentColor" /> : <Volume2 size={16} />}
                          </button>
                          <div>
                            <h3 className="font-bold text-white text-lg group-hover:text-sky-400 transition-colors">{msg.exerciseData.title}</h3>
                            <div className="flex gap-1 mt-1">
                                {msg.exerciseData.audioPreset && (
                                    <span className={`text-[10px] px-1.5 py-0.5 rounded border inline-flex items-center gap-1 ${
                                        msg.exerciseData.audioPreset === 'Cosmic' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' : 
                                        'bg-slate-500/20 text-slate-300 border-slate-500/30'
                                    }`}>
                                    <Sparkles size={8} />
                                    {msg.exerciseData.audioPreset}
                                    </span>
                                )}
                            </div>
                          </div>
                        </div>
                        <span className="text-xs bg-slate-700 text-slate-300 px-2 py-1 rounded font-mono">{msg.exerciseData.bpm} BPM</span>
                      </div>
                      <p className="text-xs text-slate-400 mb-4 line-clamp-2 pl-10">{msg.exerciseData.description}</p>
                      
                      <div className="flex flex-col gap-2">
                        <button 
                            onClick={(e) => { e.stopPropagation(); onLoadExercise(msg.exerciseData!, 'full'); }}
                            className="w-full py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors shadow-md shadow-sky-900/20"
                        >
                            <PlayCircle size={16} /> 完整演奏 (带伴奏)
                        </button>
                        <div className="flex gap-2">
                          <button 
                              onClick={(e) => { e.stopPropagation(); onLoadExercise(msg.exerciseData!, 'piano'); }}
                              className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors"
                          >
                              <Keyboard size={16} /> 纯钢琴版
                          </button>
                          <button 
                              onClick={(e) => { e.stopPropagation(); handleSaveClick(msg.id, msg.exerciseData!); }}
                              disabled={msg.isSaved}
                              className={`px-3 py-2 rounded-lg font-medium text-sm flex items-center justify-center gap-2 transition-colors border ${msg.isSaved 
                                  ? 'bg-rose-500/20 border-rose-500 text-rose-500' 
                                  : 'bg-slate-700 border-slate-600 text-slate-300 hover:bg-slate-600 hover:text-white'
                              }`}
                          >
                              {msg.isSaved ? <Check size={16} /> : <Heart size={16} className={msg.isSaved ? "fill-current" : ""} />}
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>
                )}
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-slate-800 p-4 rounded-2xl rounded-bl-none border border-slate-700 flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin text-sky-400" />
                  <span className="text-xs text-slate-400">
                    {searchQuery ? searchQuery : 'Maestro 正在谱写完整乐章 (Intro-Verse-Chorus)...'}
                  </span>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t border-slate-700 bg-slate-800/50">
            <div className="relative flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="输入歌名，我会去网上帮你搜谱..."
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-full pl-4 pr-12 py-3 focus:outline-none focus:border-sky-500 transition placeholder-slate-500 text-sm"
              />
              <button 
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="absolute right-2 p-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 disabled:hover:bg-sky-600 text-white rounded-full transition"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </>
      )}

      {activeTab === 'courses' && (
         <div className="flex-1 overflow-y-auto p-4 space-y-8 scrollbar-thin scrollbar-thumb-slate-700">
            {CATEGORIES.map((cat) => {
              const catCourses = COURSES.filter(c => c.category === cat.id);
              if (catCourses.length === 0) return null;
              return (
                <div key={cat.id}>
                  <div className="flex items-center gap-2 mb-3 sticky top-0 bg-slate-900/95 py-2 z-10 backdrop-blur-sm border-b border-slate-800/50">
                    <cat.icon className="text-sky-500" size={18} />
                    <h3 className="text-sm font-bold text-white uppercase tracking-wider">{cat.id}</h3>
                  </div>
                  <div className="space-y-3">
                    {catCourses.map(course => (
                      <div 
                        key={course.id}
                        className="bg-slate-800/40 hover:bg-slate-800 border border-slate-700/50 hover:border-sky-500/30 rounded-xl p-3 cursor-pointer group transition-all shadow-sm hover:shadow-md relative overflow-hidden"
                        onClick={() => handleStartCourse(course)}
                      >
                        <div className="flex justify-between items-start mb-1">
                            <div className="text-xl bg-slate-900/50 p-1.5 rounded-lg">{course.icon}</div>
                            <div className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
                              course.level === '入门' ? 'text-emerald-400 border-emerald-400/20 bg-emerald-400/10' : 
                              course.level === '初级' ? 'text-sky-400 border-sky-400/20 bg-sky-400/10' : 
                              course.level === '进阶' ? 'text-amber-400 border-amber-400/20 bg-amber-400/10' :
                              'text-rose-400 border-rose-400/20 bg-rose-400/10'
                            }`}>
                              {course.level}
                            </div>
                        </div>
                        <h3 className="text-slate-200 font-bold text-sm mb-1 group-hover:text-sky-400 transition-colors">{course.title}</h3>
                        <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">{course.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
         </div>
      )}
    </div>
  );
};
