
export interface MidiNote {
  midi: number;
  name: string; // e.g., "C4"
  velocity: number;
}

export enum NoteState {
  Waiting = 'WAITING',
  Active = 'ACTIVE', // In the hit window
  Hit = 'HIT',
  Missed = 'MISSED',
}

export interface SongNote {
  id: string;
  midi: number;
  startTime: number; // in seconds
  duration: number; // in seconds
  state: NoteState;
}

export interface SongMetadata {
  id: string;
  title: string;
  artist: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  bpm: number;
  notes?: SongNote[]; // User plays these
  backingNotes?: SongNote[]; // AI Auto-plays these (Background music)
  audioPreset?: 'Standard' | 'Concert' | 'Warm' | 'Bright' | 'Cosmic';
}

export interface GameStats {
  score: number;
  streak: number;
  maxStreak: number;
  hits: {
    perfect: number;
    good: number;
    miss: number;
  };
}

export interface AnalysisPayload {
  songTitle?: string;
  stats: GameStats;
}

export interface GameConfig {
  noteSpeed: number; // Pixels per second (visual) or Time lookahead
  scrollSpeed: number; // Multiplier
  sustain: boolean;
}

// Simplified structure for AI to generate
export interface AiGeneratedNote {
  note: string; // "C4", "D#4", etc.
  duration: number; // in beats (0.5, 1, 2...)
}

export interface AiGeneratedExercise {
  title: string;
  description: string;
  bpm: number;
  notes: AiGeneratedNote[]; // Main melody (Right hand)
  backingNotes?: AiGeneratedNote[]; // Accompaniment (Left hand / Strings / Pads)
  audioPreset?: 'Standard' | 'Concert' | 'Warm' | 'Bright' | 'Cosmic';
}

// Window of time (in seconds) where a hit counts
export const HIT_WINDOW = {
  PERFECT: 0.05,
  GOOD: 0.15,
  MISS: 0.3,
};

export type ThemeMode = 'classic' | 'neon' | 'fruit' | 'starry' | 'dream';
